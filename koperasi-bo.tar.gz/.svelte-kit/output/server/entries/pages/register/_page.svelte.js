import { G as head, D as escape_html, I as attr, O as maybe_selected, N as bind_props, y as pop, w as push } from "../../../chunks/index2.js";
import "@sveltejs/kit/internal";
import "../../../chunks/exports.js";
import "../../../chunks/utils.js";
import "../../../chunks/state.svelte.js";
function _page($$payload, $$props) {
  push();
  let form = $$props["form"];
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>Daftar Backoffice</title>`;
  });
  $$payload.out.push(`<div class="min-h-screen flex items-center justify-center bg-gray-100"><form method="POST" class="bg-white p-6 rounded shadow-md w-96 space-y-3"><h1 class="text-xl font-semibold">Buat Akun Baru</h1> `);
  if (form?.error) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<p class="text-red-600 text-sm">${escape_html(form.error)}</p>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> <label class="block">Email <input name="email" type="email"${attr("value", form?.values?.email ?? "")} required class="w-full border px-3 py-2 rounded"/></label> <label class="block">Password <input name="password" type="password" required class="w-full border px-3 py-2 rounded"/></label> <label class="block">Role <select name="role_id" required class="w-full border px-3 py-2 rounded"><option value=""${maybe_selected($$payload, "")} disabled selected>Pilih role</option><option${attr("value", 1)}${maybe_selected($$payload, 1)}${attr("selected", form?.values?.role_id === 1, true)}>Super Admin</option><option${attr("value", 2)}${maybe_selected($$payload, 2)}${attr("selected", form?.values?.role_id === 2, true)}>Admin</option><option${attr("value", 3)}${maybe_selected($$payload, 3)}${attr("selected", form?.values?.role_id === 3, true)}>Member</option></select></label> <button class="w-full bg-green-600 text-white py-2 rounded">Daftar</button> <p class="text-sm text-center">Sudah punya akun? <a href="/login" class="text-indigo-600">Login di sini</a></p></form></div>`);
  bind_props($$props, { form });
  pop();
}
export {
  _page as default
};

import { a as axios, e as extractErrorMessage } from "../../../chunks/api.js";
import { redirect } from "@sveltejs/kit";
const actions = {
  default: async ({ request }) => {
    const fd = await request.formData();
    const payload = {
      email: fd.get("email"),
      password: fd.get("password"),
      role_id: Number(fd.get("role_id"))
    };
    try {
      await axios.post("/register", payload);
      throw redirect(303, "/login?registered=true");
    } catch (e) {
      const errorMessage = extractErrorMessage(e);
      return {
        error: errorMessage,
        values: { email: payload.email, role_id: payload.role_id }
      };
    }
  }
};
export {
  actions
};

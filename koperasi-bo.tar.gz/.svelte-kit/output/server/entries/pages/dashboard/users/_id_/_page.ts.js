import { a as axios } from "../../../../../chunks/api.js";
import { error } from "@sveltejs/kit";
const load = async ({ params, parent }) => {
  const { user: currentUser } = await parent();
  const canManageUsers = currentUser?.role?.name === "admin" || currentUser?.role?.name === "super_admin";
  if (!canManageUsers) {
    throw error(403, "Access denied");
  }
  try {
    const { data } = await axios.get(`/users/${params.id}`);
    return {
      user: data,
      currentUser
    };
  } catch (err) {
    if (err.response?.status === 404) {
      throw error(404, "User not found");
    }
    throw error(500, "Failed to load user data");
  }
};
export {
  load
};

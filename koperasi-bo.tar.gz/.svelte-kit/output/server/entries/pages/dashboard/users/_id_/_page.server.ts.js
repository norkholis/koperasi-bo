import { a as axios } from "../../../../../chunks/api.js";
import { redirect, fail } from "@sveltejs/kit";
const actions = {
  update: async ({ request, params }) => {
    const fd = await request.formData();
    const payload = {};
    const email = fd.get("email");
    const password = fd.get("password");
    const roleId = fd.get("role_id");
    const fullName = fd.get("full_name");
    const phone = fd.get("phone");
    const address = fd.get("address");
    const isActive = fd.get("is_active") === "on";
    if (email) payload.email = email;
    if (password) payload.password = password;
    if (roleId) payload.role_id = Number(roleId);
    if (fullName) payload.full_name = fullName;
    if (phone) payload.phone = phone;
    if (address) payload.address = address;
    payload.is_active = isActive;
    try {
      await axios.put(`/users/${params.id}`, payload);
      throw redirect(303, "/dashboard/users");
    } catch (error) {
      console.error("Update user error:", error.response?.data);
      return fail(400, {
        error: error.response?.data?.message || "Gagal mengupdate user"
      });
    }
  }
};
export {
  actions
};

import { A as ensure_array_like, D as escape_html, B as attr_class, I as attr, E as stringify, N as bind_props, y as pop, w as push } from "../../../../chunks/index2.js";
import "@sveltejs/kit/internal";
import "../../../../chunks/exports.js";
import "../../../../chunks/utils.js";
import "../../../../chunks/state.svelte.js";
import "../../../../chunks/api.js";
function _page($$payload, $$props) {
  push();
  let data = $$props["data"];
  let users = data?.users ?? [];
  const currentUser = data.user;
  const canManageUsers = currentUser?.role?.name === "admin" || currentUser?.role?.name === "super_admin";
  const each_array = ensure_array_like(users);
  $$payload.out.push(`<div class="p-4 sm:p-6"><div class="flex flex-col sm:flex-row sm:items-center justify-between mb-4 sm:mb-6"><h1 class="text-xl sm:text-2xl font-bold mb-2 sm:mb-0">User Management</h1> `);
  if (canManageUsers) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<button class="w-full sm:w-auto px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 transition-colors">Add User</button>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--></div> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> <div class="bg-white shadow rounded overflow-hidden"><div class="overflow-x-auto"><table class="w-full"><thead class="bg-gray-50"><tr><th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th><th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th><th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th><th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th><th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th></tr></thead><tbody class="bg-white divide-y divide-gray-200">`);
  if (each_array.length !== 0) {
    $$payload.out.push("<!--[-->");
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let user = each_array[$$index];
      $$payload.out.push(`<tr class="hover:bg-gray-50"><td class="px-4 py-2 whitespace-nowrap text-sm text-gray-900">${escape_html(user.id)}</td><td class="px-4 py-2 whitespace-nowrap text-sm text-gray-900">${escape_html(user.email)}</td><td class="px-4 py-2 whitespace-nowrap text-sm text-gray-900">${escape_html(user.name || "Empty")}</td><td class="px-4 py-2 whitespace-nowrap text-sm text-gray-900"><span${attr_class(`px-2 py-1 text-xs rounded-full ${stringify(user.role?.name === "super_admin" ? "bg-purple-100 text-purple-800" : user.role?.name === "admin" ? "bg-blue-100 text-blue-800" : "bg-green-100 text-green-800")}`)}>${escape_html(user.role?.name || user.role_id || "Unknown")}</span></td><td class="px-4 py-2 whitespace-nowrap text-sm font-medium"><div class="flex gap-2"><button class="px-3 py-1 text-sm bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"${attr("disabled", !canManageUsers, true)}>Edit</button> <button class="px-3 py-1 text-sm bg-red-500 text-white rounded hover:bg-red-600 transition-colors"${attr("disabled", !canManageUsers || user.id === currentUser.id, true)}>Delete</button></div></td></tr>`);
    }
  } else {
    $$payload.out.push("<!--[!-->");
    $$payload.out.push(`<tr class="bg-red-100"><td colspan="5" class="px-4 py-2 text-center text-sm text-gray-900">No users found</td></tr>`);
  }
  $$payload.out.push(`<!--]--></tbody></table></div></div></div> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]-->`);
  bind_props($$props, { data });
  pop();
}
export {
  _page as default
};

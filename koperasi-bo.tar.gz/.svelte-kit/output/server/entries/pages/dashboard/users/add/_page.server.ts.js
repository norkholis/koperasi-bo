import { a as axios } from "../../../../../chunks/api.js";
import { fail, redirect } from "@sveltejs/kit";
const actions = {
  default: async ({ request }) => {
    const fd = await request.formData();
    const email = fd.get("email");
    const password = fd.get("password");
    const roleId = Number(fd.get("role_id"));
    const name = fd.get("name");
    const phoneNumber = fd.get("phone_number");
    const address = fd.get("address");
    const nik = fd.get("nik");
    if (!email || !password || !roleId || !name || !phoneNumber) {
      return fail(400, {
        error: "Email, password, nama, telepon, dan role harus diisi"
      });
    }
    if (password.length < 6) {
      return fail(400, {
        error: "Password minimal 6 karakter"
      });
    }
    let cleanNik = "";
    if (nik && nik.trim()) {
      cleanNik = nik.trim().replace(/\s+/g, "");
      if (!/^\d{16}$/.test(cleanNik)) {
        return fail(400, {
          error: `NIK harus 16 digit angka. Anda memasukkan ${cleanNik.length} karakter: "${cleanNik}"`
        });
      }
    }
    const payload = {
      email,
      password,
      name,
      address,
      phone_number: phoneNumber,
      role_id: roleId
    };
    if (cleanNik) {
      payload.nik = cleanNik;
    }
    try {
      console.log("🚀 Making API request to create user...");
      const response = await axios.post("/users", payload);
      console.log("✅ API Response Status:", response.status);
      console.log("✅ API Response Data:", response.data);
      if (response.status >= 200 && response.status < 300) {
        if (response.data?.data) {
          const newUser = response.data.data;
          console.log("👤 New user created with ID:", newUser.id, "Email:", newUser.email);
        } else {
          console.log("✅ User created successfully (no data field in response)");
        }
        throw redirect(303, "/dashboard/users?success=User berhasil ditambahkan");
      } else {
        console.warn("⚠️ Unexpected response status:", response.status);
        throw redirect(303, "/dashboard/users?success=User berhasil ditambahkan");
      }
    } catch (error) {
      if (error.status === 303) {
        throw error;
      }
      console.error("❌ Add user error:", error.response?.data);
      console.error("🔍 Full error object:", error);
      console.log("📊 Error status:", error.response?.status);
      let errorMessage = "Gagal menambahkan user";
      if (error.response?.status === 409) {
        const apiError = error.response?.data?.error || "";
        if (apiError.includes("nik") || apiError.includes("NIK") || apiError.includes("uni_users_nik")) {
          errorMessage = "NIK sudah terdaftar dalam sistem. Silakan gunakan NIK yang berbeda.";
        } else {
          errorMessage = "Email sudah terdaftar dalam sistem. Silakan gunakan email yang berbeda.";
        }
      } else if (error.response?.data?.error) {
        const apiError = error.response.data.error;
        console.log("🔍 API Error received:", apiError);
        if (apiError === "NIK already exists") {
          errorMessage = "NIK sudah terdaftar dalam sistem. Silakan gunakan NIK yang berbeda.";
        } else if (apiError === "Email already exists" || apiError.includes("email already") || apiError.includes("Email already")) {
          errorMessage = "Email sudah terdaftar dalam sistem. Silakan gunakan email yang berbeda.";
        } else if (apiError === "Invalid role" || apiError.includes("role")) {
          errorMessage = "Role yang dipilih tidak valid.";
        } else if (apiError.includes("password")) {
          errorMessage = "Password tidak memenuhi kriteria. Minimal 6 karakter.";
        } else if (apiError.includes("validation")) {
          errorMessage = "Data yang dikirim tidak valid. Silakan periksa kembali form.";
        } else {
          errorMessage = `Gagal membuat user: ${apiError}`;
        }
      } else if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.message) {
        errorMessage = `Terjadi kesalahan koneksi: ${error.message}`;
      }
      console.log("💬 About to return error message:", errorMessage);
      console.log("🔍 Error response status:", error.response?.status);
      return fail(400, {
        error: errorMessage
      });
    }
  }
};
export {
  actions
};

import { error } from "@sveltejs/kit";
const load = async ({ parent }) => {
  const { user } = await parent();
  const canManageUsers = user?.role?.name === "admin" || user?.role?.name === "super_admin";
  if (!canManageUsers) {
    throw error(403, "Access denied. Only admin and super admin can create users.");
  }
  return { user };
};
export {
  load
};

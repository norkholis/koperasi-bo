import { A as ensure_array_like, I as attr, O as maybe_selected, D as escape_html, N as bind_props, y as pop, w as push } from "../../../../../../chunks/index2.js";
import "@sveltejs/kit/internal";
import "../../../../../../chunks/exports.js";
import "../../../../../../chunks/utils.js";
import "../../../../../../chunks/state.svelte.js";
function _page($$payload, $$props) {
  push();
  let data = $$props["data"];
  const user = data.user;
  const roles = data.roles;
  const currentUser = data.currentUser;
  let isSubmitting = false;
  const canManageUsers = currentUser?.role?.name === "admin" || currentUser?.role?.name === "super_admin";
  $$payload.out.push(`<div class="p-6 max-w-2xl mx-auto"><div class="flex items-center justify-between mb-6"><h1 class="text-2xl font-bold">Edit User</h1> <button class="px-4 py-2 text-gray-600 border border-gray-300 rounded hover:bg-gray-50 transition-colors">Back to Users</button></div> `);
  if (!canManageUsers) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<div class="bg-red-50 border border-red-200 rounded-md p-4 mb-6"><p class="text-red-800">You don't have permission to edit users.</p></div>`);
  } else {
    $$payload.out.push("<!--[!-->");
    const each_array = ensure_array_like(roles);
    $$payload.out.push(`<div class="bg-white shadow rounded-lg p-6"><form method="POST" action="?/update"><div class="space-y-4"><div><label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email</label> <input type="email" id="email" name="email"${attr("value", user.email)} required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"/></div> <div><label for="name" class="block text-sm font-medium text-gray-700 mb-1">Name</label> <input type="text" id="name" name="name"${attr("value", user.name || "")} class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"/></div> <div><label for="phone_number" class="block text-sm font-medium text-gray-700 mb-1">Phone Number</label> <input type="text" id="phone_number" name="phone_number"${attr("value", user.phone_number || "")} class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"/></div> <div><label for="nik" class="block text-sm font-medium text-gray-700 mb-1">NIK</label> <input type="text" id="nik" name="nik"${attr("value", user.nik || "")} class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"/></div> <div><label for="role_id" class="block text-sm font-medium text-gray-700 mb-1">Role</label> <select id="role_id" name="role_id" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"><!--[-->`);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let role = each_array[$$index];
      $$payload.out.push(`<option${attr("value", role.id)}${maybe_selected($$payload, role.id)}${attr("selected", role.id === user.role_id, true)}>${escape_html(role.name)}</option>`);
    }
    $$payload.out.push(`<!--]--></select></div> <div><label for="password" class="block text-sm font-medium text-gray-700 mb-1">New Password (leave empty to keep current)</label> <input type="password" id="password" name="password" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"/></div></div> <div class="flex justify-end gap-3 mt-6"><button type="button" class="px-4 py-2 text-gray-600 border border-gray-300 rounded hover:bg-gray-50 transition-colors"${attr("disabled", isSubmitting, true)}>Cancel</button> <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors disabled:opacity-50"${attr("disabled", isSubmitting, true)}>${escape_html("Update User")}</button></div></form></div>`);
  }
  $$payload.out.push(`<!--]--></div>`);
  bind_props($$props, { data });
  pop();
}
export {
  _page as default
};

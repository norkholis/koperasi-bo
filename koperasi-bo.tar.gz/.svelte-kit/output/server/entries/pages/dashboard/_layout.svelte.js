import { I as attr, B as attr_class, D as escape_html, M as slot, N as bind_props, y as pop, w as push, E as stringify } from "../../../chunks/index2.js";
import "@sveltejs/kit/internal";
import "../../../chunks/exports.js";
import "../../../chunks/utils.js";
import "../../../chunks/state.svelte.js";
function _layout($$payload, $$props) {
  push();
  let user, canManageUsers, isSuper;
  let data = $$props["data"];
  let showMobileMenu = false;
  let showPinjamanDropdown = false;
  user = data.user;
  canManageUsers = user?.role?.name === "admin" || user?.role?.name === "super_admin";
  isSuper = user?.role?.name === "super_admin";
  user?.role?.name === "admin";
  user?.role?.name === "member";
  $$payload.out.push(`<nav class="bg-indigo-700 text-white"><div class="hidden md:flex p-4 justify-between"><div class="flex items-center space-x-4"><span class="font-bold">Koperasi Backoffice</span> <div class="flex space-x-2"><a href="/dashboard" class="hover:bg-indigo-600 px-3 py-1 rounded">Dashboard</a> `);
  if (canManageUsers) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<a href="/dashboard/users" class="hover:bg-indigo-600 px-3 py-1 rounded">Kelola User</a>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> <a href="/dashboard/simpanan" class="hover:bg-indigo-600 px-3 py-1 rounded">Wadiah</a> <div class="relative"><button class="hover:bg-indigo-600 px-3 py-1 rounded flex items-center gap-1"${attr("aria-expanded", showPinjamanDropdown)} aria-haspopup="true">Pinjaman <svg${attr_class(`w-4 h-4 transition-transform ${stringify("")}`)} fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clip-rule="evenodd"></path></svg></button> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--></div> <a href="/dashboard/shu" class="hover:bg-indigo-600 px-3 py-1 rounded">Laporan SHU</a> `);
  if (canManageUsers) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<a href="/dashboard/reporting" class="hover:bg-indigo-600 px-3 py-1 rounded">Laporan</a>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (isSuper) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<a href="/dashboard/super" class="hover:bg-indigo-600 px-3 py-1 rounded">Super Admin</a>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> <a href="/dashboard/profile" class="hover:bg-indigo-600 px-3 py-1 rounded">Profile</a></div></div> <div class="flex items-center space-x-4"><span class="text-sm">${escape_html(user.name || user.email)} <span class="text-indigo-200">(${escape_html(user.role?.name)})</span></span> <a href="/logout" class="bg-indigo-800 hover:bg-indigo-900 px-3 py-1 rounded text-sm">Logout</a></div></div> <div class="md:hidden"><div class="flex justify-between items-center p-4"><span class="font-bold">Koperasi Backoffice</span> <button class="p-2 rounded-md hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"${attr("aria-expanded", showMobileMenu)} aria-label="Toggle navigation menu"><svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">`);
  {
    $$payload.out.push("<!--[!-->");
    $$payload.out.push(`<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>`);
  }
  $$payload.out.push(`<!--]--></svg></button></div> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--></div></nav> <main class="p-4 sm:p-6"><!---->`);
  slot($$payload, $$props, "default", {});
  $$payload.out.push(`<!----></main>`);
  bind_props($$props, { data });
  pop();
}
export {
  _layout as default
};

import { a as axios } from "../../../chunks/api.js";
import { redirect } from "@sveltejs/kit";
const load = async ({ cookies }) => {
  const token = cookies.get("token") ?? axios.defaults.headers.Authorization;
  if (!token) throw redirect(303, "/login");
  try {
    axios.defaults.headers.Authorization = token;
    const response = await axios.get("/me");
    console.log("ME endpoint response:", response.data);
    let userData = response.data;
    if (userData.data) {
      userData = userData.data;
    }
    if (userData.role_id && !userData.role) {
      userData.role = {
        id: userData.role_id,
        name: userData.role_id === 1 ? "super_admin" : userData.role_id === 2 ? "admin" : "member"
      };
    }
    console.log("Processed user data:", userData);
    return { user: userData };
  } catch {
    throw redirect(303, "/login");
  }
};
export {
  load
};

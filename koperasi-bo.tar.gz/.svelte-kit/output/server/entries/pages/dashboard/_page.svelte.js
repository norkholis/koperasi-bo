import { N as bind_props, y as pop, w as push } from "../../../chunks/index2.js";
import "@sveltejs/kit/internal";
import "../../../chunks/exports.js";
import "../../../chunks/utils.js";
import "clsx";
import "../../../chunks/state.svelte.js";
function _page($$payload, $$props) {
  push();
  let data = $$props["data"];
  $$payload.out.push(`<div class="flex items-center justify-center min-h-screen"><div class="text-center"><div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div> <p class="mt-4 text-gray-600">Mengarahkan ke dashboard...</p></div></div>`);
  bind_props($$props, { data });
  pop();
}
export {
  _page as default
};

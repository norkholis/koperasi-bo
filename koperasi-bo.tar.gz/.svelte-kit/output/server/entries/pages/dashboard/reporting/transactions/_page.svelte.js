import { G as head, D as escape_html, A as ensure_array_like, B as attr_class, E as stringify, I as attr, N as bind_props, y as pop, w as push } from "../../../../../chunks/index2.js";
import "../../../../../chunks/api.js";
function _page($$payload, $$props) {
  push();
  let totalPages, currentPage;
  let data = $$props["data"];
  data.currentUser;
  const initialFilters = data.initialFilters;
  const error = data.error;
  let transactions = [];
  let filters = {
    ...initialFilters,
    limit: initialFilters?.limit || 50,
    offset: initialFilters?.offset || 0
  };
  let totalTransactions = 0;
  function formatCurrency(amount) {
    return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(amount);
  }
  function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString("id-ID", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  }
  function getTransactionTypeColor(type) {
    switch (type) {
      case "SIMPANAN":
        return "bg-green-100 text-green-800";
      case "PINJAMAN":
        return "bg-blue-100 text-blue-800";
      case "ANGSURAN":
        return "bg-purple-100 text-purple-800";
      case "SHU":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  }
  function getStatusColor(status) {
    switch (status) {
      case "COMPLETED":
        return "bg-green-100 text-green-800";
      case "VERIFIED":
        return "bg-blue-100 text-blue-800";
      case "PENDING":
        return "bg-yellow-100 text-yellow-800";
      case "CANCELLED":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  }
  totalPages = Math.ceil(totalTransactions / (filters.limit || 50));
  currentPage = Math.floor((filters.offset || 0) / (filters.limit || 50)) + 1;
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>Riwayat Transaksi - Koperasi Backoffice</title>`;
  });
  $$payload.out.push(`<div class="min-h-screen bg-gray-50 p-4 sm:p-6"><div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8"><div><h1 class="text-2xl sm:text-3xl font-bold text-gray-900">Riwayat Transaksi</h1> <p class="text-gray-600 mt-2">Lihat dan filter riwayat transaksi lengkap sistem</p></div> <div class="mt-4 sm:mt-0 flex gap-2"><button class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">${escape_html("Tampilkan")} Filter</button> <button class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">Export</button></div></div> `);
  if (error) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<div class="bg-red-50 border border-red-200 rounded-lg p-4 mb-8"><div class="flex"><div class="flex-shrink-0"><svg class="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path></svg></div> <div class="ml-3"><h3 class="text-sm font-medium text-red-800">Error</h3> <p class="text-sm text-red-700 mt-1">${escape_html(error)}</p></div></div></div>`);
  } else {
    $$payload.out.push("<!--[!-->");
    {
      $$payload.out.push("<!--[!-->");
    }
    $$payload.out.push(`<!--]--> `);
    {
      $$payload.out.push("<!--[!-->");
      $$payload.out.push(`<div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden"><div class="px-6 py-4 border-b border-gray-200"><h3 class="text-lg font-medium text-gray-900">Riwayat Transaksi (${escape_html(totalTransactions.toLocaleString("id-ID"))} transaksi)</h3></div> `);
      if (transactions.length === 0) {
        $$payload.out.push("<!--[-->");
        $$payload.out.push(`<div class="p-8 text-center"><svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg> <p class="text-gray-500 mt-2">Tidak ada transaksi ditemukan</p></div>`);
      } else {
        $$payload.out.push("<!--[!-->");
        const each_array = ensure_array_like(transactions);
        $$payload.out.push(`<div class="overflow-x-auto"><table class="min-w-full divide-y divide-gray-200"><thead class="bg-gray-50"><tr><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jenis</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jumlah</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Deskripsi</th></tr></thead><tbody class="bg-white divide-y divide-gray-200"><!--[-->`);
        for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
          let transaction = each_array[$$index];
          $$payload.out.push(`<tr class="hover:bg-gray-50"><td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${escape_html(transaction.id)}</td><td class="px-6 py-4 whitespace-nowrap"><div class="text-sm text-gray-900">${escape_html(transaction.user?.name || transaction.user?.email || `User #${transaction.user_id}`)}</div> <div class="text-sm text-gray-500">ID: ${escape_html(transaction.user_id)}</div></td><td class="px-6 py-4 whitespace-nowrap"><span${attr_class(`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${stringify(getTransactionTypeColor(transaction.transaction_type))}`)}>${escape_html(transaction.transaction_type)}</span></td><td class="px-6 py-4 whitespace-nowrap"><div class="text-sm text-gray-900 font-medium">${escape_html(formatCurrency(transaction.amount))}</div> <div class="text-xs text-gray-500">Sebelum: ${escape_html(formatCurrency(transaction.balance_before))}</div></td><td class="px-6 py-4 whitespace-nowrap"><span${attr_class(`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${stringify(getStatusColor(transaction.status))}`)}>${escape_html(transaction.status)}</span></td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${escape_html(formatDate(transaction.transaction_date))}</td><td class="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">${escape_html(transaction.description)}</td></tr>`);
        }
        $$payload.out.push(`<!--]--></tbody></table></div> `);
        if (totalPages > 1) {
          $$payload.out.push("<!--[-->");
          const each_array_1 = ensure_array_like(Array(Math.min(totalPages, 7)).fill(0));
          $$payload.out.push(`<div class="bg-white px-4 py-3 border-t border-gray-200 sm:px-6"><div class="flex items-center justify-between"><div class="flex-1 flex justify-between sm:hidden"><button${attr("disabled", currentPage <= 1, true)} class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed">Previous</button> <button${attr("disabled", currentPage >= totalPages, true)} class="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed">Next</button></div> <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between"><div><p class="text-sm text-gray-700">Showing <span class="font-medium">${escape_html((filters.offset || 0) + 1)}</span> to <span class="font-medium">${escape_html(Math.min((filters.offset || 0) + (filters.limit || 50), totalTransactions))}</span> of <span class="font-medium">${escape_html(totalTransactions)}</span> results</p></div> <div><nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination"><button${attr("disabled", currentPage <= 1, true)} class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"><span class="sr-only">Previous</span> <svg class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg></button> <!--[-->`);
          for (let i = 0, $$length = each_array_1.length; i < $$length; i++) {
            each_array_1[i];
            const page = i + 1;
            $$payload.out.push(`<button${attr_class(`relative inline-flex items-center px-4 py-2 border text-sm font-medium ${stringify(page === currentPage ? "z-10 bg-indigo-50 border-indigo-500 text-indigo-600" : "bg-white border-gray-300 text-gray-500 hover:bg-gray-50")}`)}>${escape_html(page)}</button>`);
          }
          $$payload.out.push(`<!--]--> <button${attr("disabled", currentPage >= totalPages, true)} class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"><span class="sr-only">Next</span> <svg class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path></svg></button></nav></div></div></div></div>`);
        } else {
          $$payload.out.push("<!--[!-->");
        }
        $$payload.out.push(`<!--]-->`);
      }
      $$payload.out.push(`<!--]--></div>`);
    }
    $$payload.out.push(`<!--]-->`);
  }
  $$payload.out.push(`<!--]--></div>`);
  bind_props($$props, { data });
  pop();
}
export {
  _page as default
};

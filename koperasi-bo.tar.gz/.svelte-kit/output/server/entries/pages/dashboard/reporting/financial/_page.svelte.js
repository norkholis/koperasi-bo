import { G as head, D as escape_html, O as maybe_selected, I as attr, N as bind_props, y as pop, w as push } from "../../../../../chunks/index2.js";
import "../../../../../chunks/api.js";
function _page($$payload, $$props) {
  push();
  let data = $$props["data"];
  data.currentUser;
  const error = data?.error || null;
  let generatingReport = false;
  let reportForm = {
    report_type: "MONTHLY",
    start_date: new Date((/* @__PURE__ */ new Date()).getFullYear(), (/* @__PURE__ */ new Date()).getMonth() - 1, 1).toISOString().split("T")[0],
    end_date: new Date((/* @__PURE__ */ new Date()).getFullYear(), (/* @__PURE__ */ new Date()).getMonth(), 0).toISOString().split("T")[0]
  };
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>Laporan Keuangan - Koperasi Backoffice</title>`;
  });
  $$payload.out.push(`<div class="min-h-screen bg-gray-50 p-4 sm:p-6"><div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8"><div><h1 class="text-2xl sm:text-3xl font-bold text-gray-900">Generate Laporan Keuangan</h1> <p class="text-gray-600 mt-2">Buat laporan keuangan berdasarkan periode dan jenis yang dipilih</p></div> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--></div> `);
  if (error) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<div class="bg-red-50 border border-red-200 rounded-lg p-4 mb-8"><div class="flex"><div class="flex-shrink-0"><svg class="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path></svg></div> <div class="ml-3"><h3 class="text-sm font-medium text-red-800">Error</h3> <p class="text-sm text-red-700 mt-1">${escape_html(error)}</p></div></div></div>`);
  } else {
    $$payload.out.push("<!--[!-->");
    $$payload.out.push(`<div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8"><h3 class="text-lg font-medium text-gray-900 mb-4">Parameter Laporan</h3> <div class="grid grid-cols-1 md:grid-cols-3 gap-4"><div><label class="block text-sm font-medium text-gray-700 mb-1">Jenis Laporan</label> <select class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">`);
    $$payload.select_value = reportForm.report_type;
    $$payload.out.push(`<option value="DAILY"${maybe_selected($$payload, "DAILY")}>Harian</option><option value="WEEKLY"${maybe_selected($$payload, "WEEKLY")}>Mingguan</option><option value="MONTHLY"${maybe_selected($$payload, "MONTHLY")}>Bulanan</option><option value="YEARLY"${maybe_selected($$payload, "YEARLY")}>Tahunan</option><option value="CUSTOM"${maybe_selected($$payload, "CUSTOM")}>Custom Range</option>`);
    $$payload.select_value = void 0;
    $$payload.out.push(`</select></div> <div><label class="block text-sm font-medium text-gray-700 mb-1">Tanggal Mulai</label> <input type="date"${attr("value", reportForm.start_date)} class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"/></div> <div><label class="block text-sm font-medium text-gray-700 mb-1">Tanggal Akhir</label> <input type="date"${attr("value", reportForm.end_date)} class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"/></div></div> <div class="mt-6"><button${attr("disabled", generatingReport, true)} class="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">`);
    {
      $$payload.out.push("<!--[!-->");
      $$payload.out.push(`Generate Laporan`);
    }
    $$payload.out.push(`<!--]--></button></div></div> `);
    {
      $$payload.out.push("<!--[!-->");
    }
    $$payload.out.push(`<!--]-->`);
  }
  $$payload.out.push(`<!--]--></div>`);
  bind_props($$props, { data });
  pop();
}
export {
  _page as default
};

const load = async ({ parent, url }) => {
  try {
    const { user: currentUser } = await parent();
    if (!currentUser) {
      return {
        currentUser: null,
        error: "User not found"
      };
    }
    const isAdmin = currentUser.role?.name === "admin" || currentUser.role?.name === "super_admin";
    if (!isAdmin) {
      return {
        currentUser,
        error: "Access denied. Admin role required."
      };
    }
    const filters = {
      user_id: url.searchParams.get("user_id") ? parseInt(url.searchParams.get("user_id")) : void 0,
      transaction_type: url.searchParams.get("transaction_type"),
      status: url.searchParams.get("status"),
      start_date: url.searchParams.get("start_date") || void 0,
      end_date: url.searchParams.get("end_date") || void 0,
      min_amount: url.searchParams.get("min_amount") ? parseInt(url.searchParams.get("min_amount")) : void 0,
      max_amount: url.searchParams.get("max_amount") ? parseInt(url.searchParams.get("max_amount")) : void 0,
      limit: url.searchParams.get("limit") ? parseInt(url.searchParams.get("limit")) : 50,
      offset: url.searchParams.get("offset") ? parseInt(url.searchParams.get("offset")) : 0
    };
    return {
      currentUser,
      initialFilters: filters
    };
  } catch (error) {
    console.error("❌ Error in transaction history page load:", error);
    return {
      currentUser: null,
      error: error instanceof Error ? error.message : "Unknown error"
    };
  }
};
export {
  load
};

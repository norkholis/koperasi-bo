import { D as escape_html, I as attr, N as bind_props, y as pop, w as push } from "../../../../chunks/index2.js";
import "@sveltejs/kit/internal";
import "../../../../chunks/exports.js";
import "../../../../chunks/utils.js";
import "../../../../chunks/state.svelte.js";
function _page($$payload, $$props) {
  push();
  let user;
  let data = $$props["data"];
  let form = $$props["form"];
  let profileLoading = false;
  let passwordLoading = false;
  user = data.user;
  $$payload.out.push(`<div class="max-w-4xl mx-auto"><div class="mb-6"><h2 class="text-2xl font-bold text-gray-900">Profile Saya</h2> <p class="text-gray-600 mt-2">Kelola informasi personal dan keamanan akun Anda</p></div> <div class="grid grid-cols-1 lg:grid-cols-2 gap-6"><div class="bg-white shadow rounded-lg"><div class="px-6 py-4 border-b border-gray-200"><h3 class="text-lg font-medium text-gray-900">Informasi Profile</h3></div> `);
  if (form?.success) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<div class="mx-6 mt-4 bg-green-50 border border-green-200 rounded-md p-4"><div class="flex"><div class="flex-shrink-0"><svg class="h-5 w-5 text-green-400" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg></div> <div class="ml-3"><p class="text-sm text-green-700">${escape_html(form.success)}</p></div></div></div>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (form?.error) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<div class="mx-6 mt-4 bg-red-50 border border-red-200 rounded-md p-4"><div class="flex"><div class="flex-shrink-0"><svg class="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path></svg></div> <div class="ml-3"><p class="text-sm text-red-700">${escape_html(form.error)}</p></div></div></div>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> <form method="POST" action="?/updateProfile" class="p-6 space-y-4"><div class="bg-gray-50 rounded-lg p-4 mb-4"><div class="grid grid-cols-2 gap-4 text-sm"><div><span class="font-medium text-gray-600">ID:</span> <span class="ml-2">${escape_html(user.id)}</span></div> <div><span class="font-medium text-gray-600">Role:</span> <span class="ml-2 capitalize">${escape_html(user.role?.name.replace("_", " "))}</span></div> <div class="col-span-2"><span class="font-medium text-gray-600">Terdaftar:</span> <span class="ml-2">${escape_html(new Date(user.created_at || "").toLocaleDateString("id-ID"))}</span></div></div></div> <div><label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email</label> <input id="email" name="email" type="email" required${attr("value", user.email)} class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"/></div> <div><label for="full_name" class="block text-sm font-medium text-gray-700 mb-1">Nama Lengkap</label> <input id="full_name" name="full_name" type="text"${attr("value", user.name || "")} class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"/></div> <div><label for="phone_number" class="block text-sm font-medium text-gray-700 mb-1">No. Telepon</label> <input id="phone_number" name="phone_number" type="tel"${attr("value", user.phone_number || "")} class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"/></div> <div><label for="address" class="block text-sm font-medium text-gray-700 mb-1">Alamat</label> <textarea id="address" name="address" rows="3" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">`);
  const $$body = escape_html(user.address || "");
  if ($$body) {
    $$payload.out.push(`${$$body}`);
  }
  $$payload.out.push(`</textarea></div> <button type="submit" class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"${attr("disabled", profileLoading, true)}>${escape_html("Update Profile")}</button></form></div> <div class="bg-white shadow rounded-lg"><div class="px-6 py-4 border-b border-gray-200"><h3 class="text-lg font-medium text-gray-900">Ubah Password</h3></div> `);
  if (form?.passwordSuccess) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<div class="mx-6 mt-4 bg-green-50 border border-green-200 rounded-md p-4"><div class="flex"><div class="flex-shrink-0"><svg class="h-5 w-5 text-green-400" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg></div> <div class="ml-3"><p class="text-sm text-green-700">${escape_html(form.passwordSuccess)}</p></div></div></div>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (form?.passwordError) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<div class="mx-6 mt-4 bg-red-50 border border-red-200 rounded-md p-4"><div class="flex"><div class="flex-shrink-0"><svg class="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path></svg></div> <div class="ml-3"><p class="text-sm text-red-700">${escape_html(form.passwordError)}</p></div></div></div>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> <form id="passwordForm" method="POST" action="?/changePassword" class="p-6 space-y-4"><div><label for="current_password" class="block text-sm font-medium text-gray-700 mb-1">Password Saat Ini</label> <input id="current_password" name="current_password" type="password" required class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"/></div> <div><label for="new_password" class="block text-sm font-medium text-gray-700 mb-1">Password Baru</label> <input id="new_password" name="new_password" type="password" required minlength="6" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"/></div> <div><label for="confirm_password" class="block text-sm font-medium text-gray-700 mb-1">Konfirmasi Password Baru</label> <input id="confirm_password" name="confirm_password" type="password" required minlength="6" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"/></div> <button type="submit" class="w-full bg-red-600 text-white py-2 px-4 rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 disabled:opacity-50"${attr("disabled", passwordLoading, true)}>${escape_html("Ubah Password")}</button></form></div></div></div>`);
  bind_props($$props, { data, form });
  pop();
}
export {
  _page as default
};

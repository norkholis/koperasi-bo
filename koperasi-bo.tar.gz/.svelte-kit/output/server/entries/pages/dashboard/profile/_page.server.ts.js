import { a as axios } from "../../../../chunks/api.js";
import { fail } from "@sveltejs/kit";
const actions = {
  updateProfile: async ({ request, cookies }) => {
    const fd = await request.formData();
    const payload = {};
    const fullName = fd.get("full_name");
    const phone = fd.get("phone_number");
    const address = fd.get("address");
    const email = fd.get("email");
    if (fullName) payload.name = fullName;
    if (phone) payload.phone_number = phone;
    if (address) payload.address = address;
    if (email) payload.email = email;
    try {
      await axios.put("/me/profile", payload);
      return { success: "Profile berhasil diupdate" };
    } catch (error) {
      console.error("Update profile error:", error.response?.data);
      return fail(400, {
        error: error.response?.data?.message || "Gagal mengupdate profile"
      });
    }
  },
  changePassword: async ({ request }) => {
    const fd = await request.formData();
    const currentPassword = fd.get("current_password");
    const newPassword = fd.get("new_password");
    const confirmPassword = fd.get("confirm_password");
    if (newPassword !== confirmPassword) {
      return fail(400, {
        passwordError: "Konfirmasi password tidak cocok"
      });
    }
    try {
      await axios.put("/me/password", {
        current_password: currentPassword,
        new_password: newPassword,
        confirm_password: confirmPassword
      });
      return { passwordSuccess: "Password berhasil diubah" };
    } catch (error) {
      console.error("Change password error:", error.response?.data);
      return fail(400, {
        passwordError: error.response?.data?.message || "Gagal mengubah password"
      });
    }
  }
};
export {
  actions
};

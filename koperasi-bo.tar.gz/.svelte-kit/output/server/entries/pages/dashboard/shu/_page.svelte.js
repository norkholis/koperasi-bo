import { G as head, D as escape_html, A as ensure_array_like, B as attr_class, E as stringify, I as attr, N as bind_props, y as pop, w as push } from "../../../../chunks/index2.js";
import "@sveltejs/kit/internal";
import "../../../../chunks/exports.js";
import "../../../../chunks/utils.js";
import "../../../../chunks/state.svelte.js";
import "../../../../chunks/api.js";
import { f as formatCurrency, a as formatDate } from "../../../../chunks/utils3.js";
function _page($$payload, $$props) {
  push();
  let data = $$props["data"];
  function safeDateFormat(shuRecord) {
    const dateValue = shuRecord.CreatedAt || shuRecord.created_at || shuRecord.tanggal_dibuat || shuRecord.date_created;
    if (!dateValue) {
      console.warn("No date field found in SHU record:", Object.keys(shuRecord));
      return "Tanggal tidak tersedia";
    }
    return formatDate(dateValue);
  }
  let shuRecords = data.shuRecords || [];
  let userShuHistory = data.userShuHistory || [];
  data.currentUser;
  const canManageSHU = data.canManageSHU || false;
  ({ tahun: (/* @__PURE__ */ new Date()).getFullYear() });
  ({
    tahun: (/* @__PURE__ */ new Date()).getFullYear()
  });
  ({
    tahun: (/* @__PURE__ */ new Date()).getFullYear()
  });
  (/* @__PURE__ */ new Date()).getFullYear();
  let savingUserSHU = false;
  {
    shuRecords = data.shuRecords || [];
    userShuHistory = data.userShuHistory || [];
  }
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>SHU Report - Koperasi Backoffice</title>`;
  });
  $$payload.out.push(`<div class="p-6"><div class="flex justify-between items-center mb-6"><div><h1 class="text-2xl font-bold text-gray-900">${escape_html(canManageSHU ? "Kelola Laporan SHU" : "SHU Saya")}</h1> <p class="text-gray-600">${escape_html(canManageSHU ? "Kelola laporan Sisa Hasil Usaha koperasi" : "Lihat riwayat dan generate SHU pribadi Anda")}</p></div> `);
  if (canManageSHU) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<div class="flex space-x-3"><button class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors">Generate Manual</button> <button class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition-colors">Generate Otomatis</button></div>`);
  } else {
    $$payload.out.push("<!--[!-->");
    $$payload.out.push(`<button class="bg-purple-500 text-white px-4 py-2 rounded hover:bg-purple-600 transition-colors">Generate SHU Saya</button>`);
  }
  $$payload.out.push(`<!--]--></div> `);
  if (canManageSHU) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<div class="bg-white rounded-lg shadow"><div class="p-4 sm:p-6 border-b border-gray-200"><h2 class="text-xl font-semibold">Daftar Laporan SHU</h2></div> `);
    if (shuRecords.length === 0) {
      $$payload.out.push("<!--[-->");
      $$payload.out.push(`<div class="p-8 text-center text-gray-500"><p>Belum ada laporan SHU yang tersedia</p> <div class="mt-4 space-x-2"><button class="text-blue-500 hover:text-blue-600">Generate manual</button> <span class="text-gray-300">atau</span> <button class="text-green-500 hover:text-green-600">Generate otomatis</button></div></div>`);
    } else {
      $$payload.out.push("<!--[!-->");
      const each_array = ensure_array_like(shuRecords);
      $$payload.out.push(`<div class="overflow-x-auto"><table class="min-w-full divide-y divide-gray-200"><thead class="bg-gray-50"><tr><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tahun</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total SHU</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal Dibuat</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th></tr></thead><tbody class="bg-white divide-y divide-gray-200"><!--[-->`);
      for (let index = 0, $$length = each_array.length; index < $$length; index++) {
        let shu = each_array[index];
        $$payload.out.push(`<tr class="hover:bg-gray-50"><td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${escape_html(shu.tahun)}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(formatCurrency(shu.total_shu))}</td><td class="px-6 py-4 whitespace-nowrap"><span${attr_class(`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${stringify(shu.status === "final" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800")}`)}>${escape_html(shu.status === "final" ? "Final" : "Draft")}</span></td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(safeDateFormat(shu))}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 space-x-2"><button class="text-blue-600 hover:text-blue-900">Detail</button> <button class="text-green-600 hover:text-green-900">PDF</button> <button class="text-red-600 hover:text-red-900">Hapus</button></td></tr>`);
      }
      $$payload.out.push(`<!--]--></tbody></table></div>`);
    }
    $$payload.out.push(`<!--]--></div>`);
  } else {
    $$payload.out.push("<!--[!-->");
    $$payload.out.push(`<div class="bg-white rounded-lg shadow"><div class="p-4 sm:p-6 border-b border-gray-200 flex justify-between items-center"><div><h2 class="text-xl font-semibold">Riwayat SHU Saya</h2> <p class="text-sm text-gray-600 mt-1">Lihat riwayat SHU yang pernah Anda terima</p></div> <div class="flex gap-2"><button class="px-3 py-2 sm:py-1 text-sm bg-purple-100 hover:bg-purple-200 text-purple-700 rounded-md transition-colors"${attr("disabled", savingUserSHU, true)}>💾 Simpan SHU</button> <button class="px-3 py-2 sm:py-1 text-sm bg-gray-100 hover:bg-gray-200 rounded-md transition-colors">🔄 Refresh</button></div></div> `);
    if (userShuHistory.length === 0) {
      $$payload.out.push("<!--[-->");
      $$payload.out.push(`<div class="p-8 text-center text-gray-500"><p>Belum ada riwayat SHU tersimpan untuk akun Anda</p> <div class="mt-4 p-4 bg-blue-50 rounded-lg text-sm text-blue-700"><p class="font-medium mb-2">ℹ️ Cara Mendapatkan SHU:</p> <ul class="text-left space-y-1"><li>• Klik tombol "💾 Simpan SHU" untuk menyimpan
                                SHU tahunan Anda</li> <li>• SHU dihitung berdasarkan kontribusi simpanan
                                dan transaksi Anda</li> <li>• Hasil tersimpan akan muncul di riwayat dengan
                                status draft/final</li> <li>• Jika tombol tidak berfungsi, hubungi admin</li></ul></div> <div class="flex gap-2 justify-center mt-4"><button class="px-4 py-2 bg-purple-500 text-white rounded hover:bg-purple-600 transition-colors">💾 Simpan SHU Saya</button> <button class="px-4 py-2 text-purple-500 border border-purple-500 rounded hover:bg-purple-50 transition-colors">🧮 Generate SHU (Legacy)</button></div></div>`);
    } else {
      $$payload.out.push("<!--[!-->");
      const each_array_1 = ensure_array_like(userShuHistory);
      $$payload.out.push(`<div class="overflow-x-auto"><table class="min-w-full divide-y divide-gray-200"><thead class="bg-gray-50"><tr><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Periode</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jasa Modal</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jasa Usaha</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total SHU</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th></tr></thead><tbody class="bg-white divide-y divide-gray-200"><!--[-->`);
      for (let index = 0, $$length = each_array_1.length; index < $$length; index++) {
        let userShu = each_array_1[index];
        $$payload.out.push(`<tr class="hover:bg-gray-50"><td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${escape_html(userShu.shu?.tahun || userShu.periode || userShu.tahun || userShu.year || "N/A")}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(formatCurrency(userShu.jumlah_modal || userShu.jasa_modal || userShu.JasaModal || 0))}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(formatCurrency(userShu.jumlah_usaha || userShu.jasa_usaha || userShu.JasaUsaha || 0))}</td><td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${escape_html(formatCurrency(userShu.shu_diterima || userShu.total_shu_anggota || userShu.TotalSHUAnggota || userShu.total_shu || userShu.TotalSHU || 0))}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><span${attr_class(`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${stringify(userShu.shu?.status === "final" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800")}`)}>${escape_html(userShu.shu?.status === "final" ? "Final" : "Draft")}</span></td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(formatDate(userShu.created_at || userShu.CreatedAt || userShu.tanggal_generate || userShu.TanggalGenerate || (/* @__PURE__ */ new Date()).toISOString()))}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">`);
        if (userShu.shu?.tahun) {
          $$payload.out.push("<!--[-->");
          $$payload.out.push(`<button class="text-blue-600 hover:text-blue-700 text-sm"${attr("disabled", savingUserSHU, true)}>💾 Simpan Ulang</button>`);
        } else {
          $$payload.out.push("<!--[!-->");
        }
        $$payload.out.push(`<!--]--></td></tr>`);
      }
      $$payload.out.push(`<!--]--></tbody></table></div>`);
    }
    $$payload.out.push(`<!--]--></div>`);
  }
  $$payload.out.push(`<!--]--></div> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]-->`);
  bind_props($$props, { data });
  pop();
}
export {
  _page as default
};

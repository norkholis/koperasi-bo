import { G as head, D as escape_html, A as ensure_array_like, B as attr_class, E as stringify, I as attr, N as bind_props, y as pop, w as push } from "../../../../chunks/index2.js";
import "@sveltejs/kit/internal";
import "../../../../chunks/exports.js";
import "../../../../chunks/utils.js";
import "../../../../chunks/state.svelte.js";
import "../../../../chunks/api.js";
function _page($$payload, $$props) {
  push();
  let data = $$props["data"];
  let loans = data.loans || [];
  let pendingInstallments = data.pendingInstallments || [];
  data.activeBungaOptions || [];
  const currentUser = data.currentUser;
  const selectedUserId = data.selectedUserId;
  console.log("🚀 Pinjaman page loaded");
  console.log("👤 Current user:", currentUser?.email, currentUser?.role?.name);
  console.log("🎯 Selected User ID:", selectedUserId);
  console.log("💼 Loans count:", loans.length);
  if (loans.length > 0) {
    console.log("✅ Loans loaded successfully:", loans.length);
    console.log("🔍 First loan:", loans[0]);
    console.log("🔍 First loan fields:");
    console.log("  - jumlah_pinjaman:", loans[0].jumlah_pinjaman, typeof loans[0].jumlah_pinjaman);
    console.log("  - lama_bulan:", loans[0].lama_bulan, typeof loans[0].lama_bulan);
    console.log("  - kode_pinjaman:", loans[0].kode_pinjaman, typeof loans[0].kode_pinjaman);
    console.log("📋 All loans status summary:");
    loans.forEach((loan, index) => {
      console.log(`  Loan ${index + 1}: status="${loan.status}" sisa_angsuran=${loan.sisa_angsuran}`);
    });
  } else {
    console.log("⚠️ No loans found");
  }
  if (data.error) {
    console.error("❌ Page data error:", data.error);
  }
  const isAdmin = currentUser?.role?.name === "admin" || currentUser?.role?.name === "super_admin";
  const isMember = currentUser?.role?.name === "member";
  let isNavigating = false;
  function formatCurrency(amount) {
    console.log("💰 formatCurrency called with:", amount, typeof amount);
    if (amount === null || amount === void 0 || isNaN(amount)) {
      console.log("⚠️ formatCurrency returning 'Rp 0' for invalid amount:", amount);
      return "Rp 0";
    }
    const formatted = new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(amount);
    console.log("✅ formatCurrency formatted", amount, "to", formatted);
    return formatted;
  }
  function formatDate(dateString) {
    if (!dateString) {
      return "Tanggal tidak tersedia";
    }
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        return "Tanggal tidak valid";
      }
      return date.toLocaleDateString("id-ID", {
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      });
    } catch (error) {
      console.error("Error formatting date:", error);
      return "Tanggal error";
    }
  }
  function getStatusColor(status) {
    const colors = {
      proses: "bg-yellow-100 text-yellow-800 border-yellow-200",
      disetujui: "bg-green-100 text-green-800 border-green-200",
      lunas: "bg-blue-100 text-blue-800 border-blue-200",
      macet: "bg-red-100 text-red-800 border-red-200",
      verified: "bg-green-100 text-green-800 border-green-200",
      kurang: "bg-orange-100 text-orange-800 border-orange-200",
      lebih: "bg-purple-100 text-purple-800 border-purple-200"
    };
    return colors[status] || "bg-gray-100 text-gray-800 border-gray-200";
  }
  function getStatusText(status) {
    const statusMap = {
      proses: "Proses",
      disetujui: "Disetujui",
      lunas: "Lunas",
      macet: "Macet",
      verified: "Terverifikasi",
      kurang: "Kurang",
      lebih: "Lebih"
    };
    return statusMap[status] || status;
  }
  function getEffectiveInterestRate(loan) {
    if (loan.bunga_persen && loan.bunga_persen > 0) {
      return loan.bunga_persen;
    }
    const principal = loan.jumlah_pinjaman / loan.lama_bulan;
    const totalPayment = loan.jumlah_angsuran;
    if (totalPayment > principal) {
      const interestAmount = totalPayment - principal;
      const monthlyInterestRate = interestAmount / principal * 100;
      return Math.round(monthlyInterestRate * 100) / 100;
    }
    return 0;
  }
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>Pinjaman - Koperasi Backoffice</title>`;
  });
  $$payload.out.push(`<div class="p-4 sm:p-6"><div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4"><div class="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4"><h1 class="text-xl sm:text-2xl font-bold">${escape_html(isMember ? "Pinjaman Saya" : "Manajemen Pinjaman")}</h1> `);
  if (selectedUserId && isAdmin) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<a href="/dashboard/pinjaman" class="text-sm text-blue-600 hover:text-blue-800 underline">← Kembali ke Semua Pinjaman</a>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--></div> `);
  if (selectedUserId && isAdmin) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<div class="text-sm text-gray-600">Menampilkan pinjaman untuk User ID: #${escape_html(selectedUserId)}</div>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--></div> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (isMember || selectedUserId) {
    $$payload.out.push("<!--[-->");
    const each_array = ensure_array_like(loans.filter((loan) => loan.status === "disetujui"));
    const each_array_1 = ensure_array_like(loans);
    $$payload.out.push(`<div class="mb-8"><div class="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-4 gap-3"><h2 class="text-lg sm:text-xl font-semibold">Pinjaman Aktif</h2> `);
    if (isMember) {
      $$payload.out.push("<!--[-->");
      $$payload.out.push(`<button class="w-full sm:w-auto bg-blue-500 text-white px-4 py-3 sm:py-2 rounded hover:bg-blue-600 transition-colors">Ajukan Pinjaman</button>`);
    } else {
      $$payload.out.push("<!--[!-->");
    }
    $$payload.out.push(`<!--]--></div> <div class="grid gap-4"><!--[-->`);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let loan = each_array[$$index];
      $$payload.out.push(`<div class="bg-white p-6 rounded-lg shadow border"><div class="flex justify-between items-start"><div class="flex-1"><div class="flex items-center gap-2 mb-2"><h3 class="text-lg font-semibold">Pinjaman #${escape_html(loan.kode_pinjaman)}</h3> <span${attr_class(`px-2 py-1 text-xs rounded-full border ${stringify(getStatusColor(loan.status))}`)}>${escape_html(getStatusText(loan.status))}</span></div> <div class="grid grid-cols-2 gap-4 text-sm text-gray-600"><div><p><span class="font-medium">Jumlah:</span> ${escape_html(formatCurrency(loan.jumlah_pinjaman))}</p> <p><span class="font-medium">Tenor:</span> ${escape_html(loan.lama_bulan)} bulan</p> <p><span class="font-medium">Ujrah:</span> ${escape_html(getEffectiveInterestRate(loan))}%</p></div> <div><p><span class="font-medium">Angsuran/bulan:</span> ${escape_html(formatCurrency(loan.jumlah_angsuran))}</p> <p><span class="font-medium">Sisa angsuran:</span> ${escape_html(loan.sisa_angsuran)} kali</p> <p><span class="font-medium">Diajukan:</span> ${escape_html(formatDate(loan.created_at))}</p></div></div></div> <div class="flex gap-2 ml-4">`);
      if (loan.status === "disetujui" && isMember) {
        $$payload.out.push("<!--[-->");
        $$payload.out.push(`<button class="px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600 transition-colors">Bayar Angsuran</button>`);
      } else {
        $$payload.out.push("<!--[!-->");
      }
      $$payload.out.push(`<!--]--> <button class="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors">Detail</button></div></div></div>`);
    }
    $$payload.out.push(`<!--]--> `);
    if (loans.filter((loan) => loan.status === "disetujui" && loan.sisa_angsuran > 0).length === 0) {
      $$payload.out.push("<!--[-->");
      $$payload.out.push(`<div class="text-center py-8 text-gray-500">`);
      if (isMember) {
        $$payload.out.push("<!--[-->");
        $$payload.out.push(`Belum ada pinjaman aktif. <button class="text-blue-600 hover:text-blue-800 underline">Ajukan pinjaman pertama</button>`);
      } else {
        $$payload.out.push("<!--[!-->");
        $$payload.out.push(`Tidak ada pinjaman aktif untuk user ini.`);
      }
      $$payload.out.push(`<!--]--></div>`);
    } else {
      $$payload.out.push("<!--[!-->");
    }
    $$payload.out.push(`<!--]--></div></div> <div class="mb-8"><h2 class="text-lg sm:text-xl font-semibold mb-4">Riwayat Pinjaman</h2> <div class="bg-white rounded-lg shadow overflow-hidden"><div class="overflow-x-auto"><table class="w-full"><thead class="bg-gray-50"><tr><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kode</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jumlah</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tenor</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th></tr></thead><tbody class="bg-white divide-y divide-gray-200"><!--[-->`);
    for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
      let loan = each_array_1[$$index_1];
      $$payload.out.push(`<tr class="hover:bg-gray-50"><td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${escape_html(loan.kode_pinjaman)}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(formatCurrency(loan.jumlah_pinjaman))}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(loan.lama_bulan)} bulan</td><td class="px-6 py-4 whitespace-nowrap"><span${attr_class(`px-2 py-1 text-xs rounded-full border ${stringify(getStatusColor(loan.status))}`)}>${escape_html(getStatusText(loan.status))}</span></td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(formatDate(loan.created_at))}</td><td class="px-6 py-4 whitespace-nowrap text-sm font-medium"><button class="text-blue-600 hover:text-blue-900 mr-2">Detail</button></td></tr>`);
    }
    $$payload.out.push(`<!--]--></tbody></table></div></div></div>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (isAdmin && !selectedUserId) {
    $$payload.out.push("<!--[-->");
    const each_array_3 = ensure_array_like(loans);
    const each_array_4 = ensure_array_like(loans);
    if (pendingInstallments.length > 0) {
      $$payload.out.push("<!--[-->");
      const each_array_2 = ensure_array_like(pendingInstallments);
      $$payload.out.push(`<div class="mb-8"><h2 class="text-lg sm:text-xl font-semibold mb-4">Angsuran Menunggu Verifikasi</h2> <div class="bg-white rounded-lg shadow overflow-hidden"><div class="overflow-x-auto"><table class="w-full"><thead class="bg-gray-50"><tr><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Pinjaman</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Angsuran Ke</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th></tr></thead><tbody class="bg-white divide-y divide-gray-200"><!--[-->`);
      for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
        let installment = each_array_2[$$index_2];
        $$payload.out.push(`<tr class="hover:bg-gray-50"><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(installment.user?.name || installment.user?.email || `User #${installment.user_id}`)}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(installment.pinjaman?.kode_pinjaman || `#${installment.pinjaman_id}`)}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(installment.angsuran_ke)}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(formatCurrency(installment.total_bayar))}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(formatDate(installment.tanggal_bayar))}</td><td class="px-6 py-4 whitespace-nowrap text-sm font-medium"><div class="flex gap-2"><button class="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors">Detail</button> <button class="px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600 transition-colors">Verifikasi</button> <button class="px-3 py-1 bg-orange-500 text-white rounded hover:bg-orange-600 transition-colors">Kurang</button></div></td></tr>`);
      }
      $$payload.out.push(`<!--]--></tbody></table></div></div></div>`);
    } else {
      $$payload.out.push("<!--[!-->");
    }
    $$payload.out.push(`<!--]--> <div class="mb-8"><h2 class="text-xl font-semibold mb-4">Semua Pinjaman</h2> <div class="bg-white rounded-lg shadow overflow-hidden"><div class="hidden md:block overflow-x-auto"><table class="w-full"><thead class="bg-gray-50"><tr><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kode</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jumlah</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sisa</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th></tr></thead><tbody class="bg-white divide-y divide-gray-200"><!--[-->`);
    for (let $$index_3 = 0, $$length = each_array_3.length; $$index_3 < $$length; $$index_3++) {
      let loan = each_array_3[$$index_3];
      $$payload.out.push(`<tr class="hover:bg-gray-50"><td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${escape_html(loan.kode_pinjaman)}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(loan.user?.name || loan.user?.email || `User #${loan.user_id}`)}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(formatCurrency(loan.jumlah_pinjaman))}</td><td class="px-6 py-4 whitespace-nowrap"><span${attr_class(`px-2 py-1 text-xs rounded-full border ${stringify(getStatusColor(loan.status))}`)}>${escape_html(getStatusText(loan.status))}</span></td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(loan.sisa_angsuran)}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(formatDate(loan.created_at))}</td><td class="px-6 py-4 whitespace-nowrap text-sm font-medium"><div class="flex gap-2">`);
      if (loan.status === "proses") {
        $$payload.out.push("<!--[-->");
        $$payload.out.push(`<button class="px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600 transition-colors">Setujui</button> <button class="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 transition-colors">Tolak</button>`);
      } else {
        $$payload.out.push("<!--[!-->");
      }
      $$payload.out.push(`<!--]--> <button class="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors">Detail</button> <button${attr("disabled", isNavigating, true)} class="px-3 py-1 bg-purple-500 text-white rounded hover:bg-purple-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">`);
      {
        $$payload.out.push("<!--[!-->");
        $$payload.out.push(`Lihat Detail`);
      }
      $$payload.out.push(`<!--]--></button></div></td></tr>`);
    }
    $$payload.out.push(`<!--]--></tbody></table></div> <div class="md:hidden divide-y divide-gray-200"><!--[-->`);
    for (let $$index_4 = 0, $$length = each_array_4.length; $$index_4 < $$length; $$index_4++) {
      let loan = each_array_4[$$index_4];
      $$payload.out.push(`<div class="p-4 bg-white hover:bg-gray-50"><div class="flex items-start justify-between mb-3"><div><h3 class="text-sm font-medium text-gray-900">${escape_html(loan.kode_pinjaman)}</h3> <p class="text-xs text-gray-500 mt-1">${escape_html(loan.user?.name || loan.user?.email || `User #${loan.user_id}`)}</p> <p class="text-lg font-semibold text-blue-600 mt-1">${escape_html(formatCurrency(loan.jumlah_pinjaman))}</p></div> <span${attr_class(`px-2 py-1 text-xs rounded-full border ${stringify(getStatusColor(loan.status))}`)}>${escape_html(getStatusText(loan.status))}</span></div> <div class="grid grid-cols-2 gap-3 text-sm text-gray-600 mb-4"><div><span class="font-medium">Sisa angsuran:</span> ${escape_html(loan.sisa_angsuran)} kali</div> <div><span class="font-medium">Tanggal:</span> ${escape_html(formatDate(loan.created_at))}</div></div> <div class="flex flex-col gap-2">`);
      if (loan.status === "proses") {
        $$payload.out.push("<!--[-->");
        $$payload.out.push(`<div class="flex gap-2"><button class="flex-1 px-3 py-2 bg-green-500 text-white rounded hover:bg-green-600 transition-colors text-sm">✓ Setujui</button> <button class="flex-1 px-3 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition-colors text-sm">✗ Tolak</button></div>`);
      } else {
        $$payload.out.push("<!--[!-->");
      }
      $$payload.out.push(`<!--]--> <div class="flex gap-2"><button class="flex-1 px-3 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors text-sm">Detail</button> <button${attr("disabled", isNavigating, true)} class="flex-1 px-3 py-2 bg-purple-500 text-white rounded hover:bg-purple-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-sm">`);
      {
        $$payload.out.push("<!--[!-->");
        $$payload.out.push(`Lihat Detail`);
      }
      $$payload.out.push(`<!--]--></button></div></div></div>`);
    }
    $$payload.out.push(`<!--]--></div></div></div>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--></div> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]-->`);
  bind_props($$props, { data });
  pop();
}
export {
  _page as default
};

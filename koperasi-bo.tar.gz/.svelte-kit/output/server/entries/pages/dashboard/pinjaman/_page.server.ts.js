import { a as axios } from "../../../../chunks/api.js";
function transformLoan(pinjaman) {
  if (!pinjaman || typeof pinjaman !== "object") {
    console.error("❌ Invalid pinjaman object:", pinjaman);
    throw new Error("Invalid pinjaman object");
  }
  const transformed = {
    id: pinjaman.ID || pinjaman.id || 0,
    created_at: pinjaman.CreatedAt || pinjaman.created_at || "",
    kode_pinjaman: pinjaman.KodePinjaman || pinjaman.kode_pinjaman || "",
    user_id: pinjaman.UserID || pinjaman.user_id || 0,
    tanggal_pinjam: pinjaman.TanggalPinjam || pinjaman.tanggal_pinjam || "",
    jumlah_pinjaman: pinjaman.JumlahPinjaman || pinjaman.jumlah_pinjaman || 0,
    bunga_persen: pinjaman.BungaPersen || pinjaman.bunga_persen || 0,
    lama_bulan: pinjaman.LamaBulan || pinjaman.lama_bulan || 0,
    jumlah_angsuran: pinjaman.JumlahAngsuran || pinjaman.jumlah_angsuran || 0,
    sisa_angsuran: pinjaman.SisaAngsuran || pinjaman.sisa_angsuran || 0,
    status: pinjaman.Status || pinjaman.status || "proses",
    user: pinjaman.User || pinjaman.user ? {
      id: pinjaman.User?.ID || pinjaman.user?.ID || pinjaman.User?.id || pinjaman.user?.id,
      name: pinjaman.User?.Name || pinjaman.user?.Name || pinjaman.User?.name || pinjaman.user?.name || "",
      email: pinjaman.User?.Email || pinjaman.user?.Email || pinjaman.User?.email || pinjaman.user?.email || "",
      address: pinjaman.User?.Address || pinjaman.user?.Address || pinjaman.User?.address || pinjaman.user?.address || "",
      phone_number: pinjaman.User?.PhoneNumber || pinjaman.user?.PhoneNumber || pinjaman.User?.phone_number || pinjaman.user?.phone_number || "",
      nik: pinjaman.User?.NIK || pinjaman.user?.NIK || pinjaman.User?.nik || pinjaman.user?.nik || "",
      role_id: pinjaman.User?.RoleID || pinjaman.user?.RoleID || pinjaman.User?.role_id || pinjaman.user?.role_id || 0,
      role: pinjaman.User?.Role || pinjaman.user?.Role || pinjaman.User?.role || pinjaman.user?.role
    } : void 0
  };
  console.log("🔄 Transforming loan:", pinjaman);
  console.log("✅ Transformed result:", transformed);
  if (transformed.bunga_persen === 0 && (pinjaman.BungaPersen || pinjaman.bunga_persen)) {
    console.warn("⚠️ Interest rate mismatch detected:");
    console.warn("  - Input BungaPersen:", pinjaman.BungaPersen);
    console.warn("  - Input bunga_persen:", pinjaman.bunga_persen);
    console.warn("  - Output bunga_persen:", transformed.bunga_persen);
  }
  return transformed;
}
function transformInstallment(angsuran) {
  return {
    id: angsuran.ID,
    pinjaman_id: angsuran.pinjaman_id || angsuran.PinjamanID,
    // Support both formats
    angsuran_ke: angsuran.angsuran_ke || angsuran.AngsuranKe,
    tanggal_bayar: angsuran.tanggal_bayar || angsuran.TanggalBayar,
    pokok: angsuran.pokok || angsuran.Pokok,
    bunga: angsuran.bunga || angsuran.Bunga,
    denda: angsuran.denda || angsuran.Denda || 0,
    total_bayar: angsuran.total_bayar || angsuran.TotalBayar || (angsuran.pokok || angsuran.Pokok || 0) + (angsuran.bunga || angsuran.Bunga || 0) + (angsuran.denda || angsuran.Denda || 0),
    user_id: angsuran.user_id || angsuran.UserID || angsuran.User && (angsuran.User.ID || angsuran.User.id) || 0,
    status: angsuran.status || angsuran.Status || "proses",
    // New fields from API: ImageBuktiTransfer / image_bukti_transfer, NoRekening / no_rekening, BankName / bank_name
    image_bukti_transfer: angsuran.image_bukti_transfer || angsuran.ImageBuktiTransfer || angsuran.ImageBukti || void 0,
    no_rekening: angsuran.no_rekening || angsuran.NoRekening || angsuran.NoRek || void 0,
    bank_name: angsuran.bank_name || angsuran.BankName || angsuran.Bank || void 0,
    pinjaman: angsuran.pinjaman ? transformLoan(angsuran.pinjaman) : void 0,
    user: angsuran.user || angsuran.User
  };
}
const load = async ({ parent, url, cookies }) => {
  console.log("🚀 Loading pinjaman page data");
  try {
    const { user: currentUser } = await parent();
    console.log("👤 Current user:", currentUser?.email, currentUser?.role?.name);
    if (!currentUser) {
      console.error("❌ No current user found");
      return {
        currentUser: null,
        loans: [],
        pendingInstallments: [],
        error: "User not found"
      };
    }
    const selectedUserId = url.searchParams.get("user_id");
    console.log("🎯 Selected User ID:", selectedUserId);
    const isAdmin = currentUser.role?.name === "admin" || currentUser.role?.name === "super_admin";
    const isMember = currentUser.role?.name === "member";
    console.log("🔐 User permissions:", { isAdmin, isMember });
    let loans = [];
    let pendingInstallments = [];
    try {
      if (selectedUserId) {
        console.log("📊 Fetching loans for specific user:", selectedUserId);
        const response = await axios.get(`/pinjaman?user_id=${selectedUserId}`);
        console.log("📦 Raw loans response for user:", response.data);
        const rawLoans = response.data.data || [];
        console.log("🔍 Raw loans array for user:", rawLoans);
        loans = rawLoans.map((loan) => {
          console.log("🔄 Transforming loan:", loan);
          const transformed = transformLoan(loan);
          console.log("✅ Transformed result:", transformed);
          return transformed;
        });
      } else if (isMember) {
        console.log("📊 Fetching loans for member user:", currentUser.id);
        const response = await axios.get(`/pinjaman?user_id=${currentUser.id}`);
        console.log("📦 Raw loans response for member:", response.data);
        const rawLoans = response.data.data || [];
        console.log("🔍 Raw loans array for member:", rawLoans);
        loans = rawLoans.map((loan) => {
          console.log("🔄 Transforming loan:", loan);
          const transformed = transformLoan(loan);
          console.log("✅ Transformed result:", transformed);
          return transformed;
        });
      } else if (isAdmin) {
        console.log("📊 Fetching ALL loans for admin");
        console.log("🔗 API URL:", "/pinjaman");
        try {
          const response = await axios.get("/pinjaman");
          console.log("📦 Raw ALL loans response status:", response.status);
          console.log("📦 Raw ALL loans response data:", response.data);
          console.log("📦 Response data type:", typeof response.data);
          console.log("📦 Response data structure:", Object.keys(response.data || {}));
          const rawLoans = response.data.data || [];
          console.log("🔍 Raw ALL loans array:", rawLoans.length, "loans");
          console.log("🔍 Raw loans array type:", Array.isArray(rawLoans));
          if (rawLoans.length > 0) {
            console.log("🔍 Sample loan from API:", rawLoans[0]);
            console.log("🔍 Sample loan keys:", Object.keys(rawLoans[0] || {}));
          } else {
            console.log("⚠️ API returned empty loans array");
            console.log("🔍 Full API response:", JSON.stringify(response.data, null, 2));
          }
          loans = rawLoans.map((loan) => {
            console.log("🔄 Transforming loan:", loan);
            const transformed = transformLoan(loan);
            console.log("✅ Transformed result:", transformed);
            return transformed;
          });
          console.log("✅ Total loans loaded for admin:", loans.length);
        } catch (apiError) {
          console.error("❌ API Error fetching all loans:", apiError);
          if (apiError && typeof apiError === "object" && "response" in apiError) {
            const axiosError = apiError;
            console.error("❌ API error status:", axiosError.response?.status);
            console.error("❌ API error data:", axiosError.response?.data);
            console.error("❌ API error headers:", axiosError.response?.headers);
          }
          if (apiError && typeof apiError === "object" && "message" in apiError) {
            console.error("❌ API error message:", apiError.message);
          }
        }
      }
      console.log("✅ Transformed loans:", loans.length);
      if (loans.length > 0) {
        console.log("🔍 First loan:", loans[0]);
      } else {
        console.log("⚠️ No loans found after transformation");
      }
    } catch (error) {
      console.error("❌ Error fetching loans:", error);
      if (error instanceof Error) {
        console.error("❌ Error message:", error.message);
      }
      if (error && typeof error === "object" && "response" in error) {
        const axiosError = error;
        console.error("❌ Axios error response:", axiosError.response?.data);
        console.error("❌ Axios error status:", axiosError.response?.status);
      }
    }
    if (isAdmin && !selectedUserId) {
      try {
        console.log("📊 Fetching pending installments");
        const response = await axios.get("/angsuran/pending");
        console.log("📦 Raw pending installments response:", response.data);
        const rawInstallments = response.data.data || [];
        pendingInstallments = rawInstallments.map(transformInstallment);
        console.log("✅ Transformed pending installments:", pendingInstallments.length);
      } catch (error) {
        console.error("❌ Error fetching pending installments:", error);
      }
    }
    let activeBungaOptions = [];
    try {
      console.log("📊 Fetching active bunga options");
      const bungaResponse = await axios.get("/bunga-options", {
        params: { active: true }
      });
      console.log("📦 Raw bunga options response:", bungaResponse.data);
      const rawBungaOptions = bungaResponse.data.data || [];
      activeBungaOptions = rawBungaOptions.map((item) => ({
        id: item.ID,
        nama: item.nama,
        persen: item.persen,
        deskripsi: item.deskripsi,
        is_active: item.is_active,
        created_by: item.created_by,
        created_by_user: item.created_by_user ? {
          id: item.created_by_user.ID,
          name: item.created_by_user.Name || item.created_by_user.Email,
          email: item.created_by_user.Email
        } : void 0,
        created_at: item.CreatedAt,
        updated_at: item.UpdatedAt
      }));
      console.log("✅ Active bunga options loaded and transformed:", activeBungaOptions.length);
      console.log("🔍 First bunga option after transformation:", activeBungaOptions[0]);
    } catch (error) {
      console.error("❌ Error fetching bunga options:", error);
      activeBungaOptions = [];
    }
    console.log("✅ Pinjaman page data loaded successfully");
    console.log("📊 Final data:", {
      loansCount: loans.length,
      pendingInstallmentsCount: pendingInstallments.length,
      activeBungaOptionsCount: activeBungaOptions.length,
      selectedUserId
    });
    return {
      currentUser,
      loans,
      pendingInstallments,
      activeBungaOptions,
      selectedUserId: selectedUserId ? parseInt(selectedUserId) : null
    };
  } catch (error) {
    console.error("❌ Error in pinjaman page load:", error);
    return {
      currentUser: null,
      loans: [],
      pendingInstallments: [],
      error: error instanceof Error ? error.message : "Unknown error"
    };
  }
};
export {
  load
};

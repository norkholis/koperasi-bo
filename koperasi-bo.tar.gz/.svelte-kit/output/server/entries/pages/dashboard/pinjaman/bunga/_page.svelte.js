import { G as head, A as ensure_array_like, D as escape_html, B as attr_class, E as stringify, I as attr, N as bind_props, y as pop, w as push } from "../../../../../chunks/index2.js";
import "@sveltejs/kit/internal";
import "../../../../../chunks/exports.js";
import "../../../../../chunks/utils.js";
import "../../../../../chunks/state.svelte.js";
import "../../../../../chunks/api.js";
function _page($$payload, $$props) {
  push();
  let data = $$props["data"];
  let bungaOptions = data.bungaOptions || [];
  data.currentUser;
  const canManageBunga = data.canManageBunga || false;
  function formatPercentage(value) {
    return `${value}%`;
  }
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>Manajemen Bunga - Koperasi Backoffice</title>`;
  });
  $$payload.out.push(`<div class="container mx-auto px-4 py-8"><div class="flex justify-between items-center mb-6"><div><h1 class="text-3xl font-bold text-gray-900">Manajemen Ujrah</h1> <p class="text-gray-600 mt-2">Kelola opsi ujrah untuk pembiayaan anggota</p></div> `);
  if (canManageBunga) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<button class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors">+ Tambah Ujrah</button>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--></div> `);
  {
    $$payload.out.push("<!--[!-->");
    if (bungaOptions.length === 0) {
      $$payload.out.push("<!--[-->");
      $$payload.out.push(`<div class="text-center py-12"><div class="text-gray-400 text-6xl mb-4">📊</div> <h3 class="text-xl font-medium text-gray-900 mb-2">Belum ada ujrah</h3> <p class="text-gray-600 mb-6">Tambahkan opsi ujrah pertama untuk memulai</p> `);
      if (canManageBunga) {
        $$payload.out.push("<!--[-->");
        $$payload.out.push(`<button class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors">Tambah Ujrah Pertama</button>`);
      } else {
        $$payload.out.push("<!--[!-->");
      }
      $$payload.out.push(`<!--]--></div>`);
    } else {
      $$payload.out.push("<!--[!-->");
      const each_array = ensure_array_like(bungaOptions);
      $$payload.out.push(`<div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden"><div class="overflow-x-auto"><table class="min-w-full divide-y divide-gray-200"><thead class="bg-gray-50"><tr><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama Bunga</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Persentase</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Deskripsi</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dibuat Oleh</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal</th>`);
      if (canManageBunga) {
        $$payload.out.push("<!--[-->");
        $$payload.out.push(`<th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>`);
      } else {
        $$payload.out.push("<!--[!-->");
      }
      $$payload.out.push(`<!--]--></tr></thead><tbody class="bg-white divide-y divide-gray-200"><!--[-->`);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let bunga = each_array[$$index];
        $$payload.out.push(`<tr class="hover:bg-gray-50"><td class="px-6 py-4 whitespace-nowrap"><div class="text-sm font-medium text-gray-900">${escape_html(bunga.nama)}</div></td><td class="px-6 py-4 whitespace-nowrap"><div class="text-sm text-gray-900 font-semibold">${escape_html(formatPercentage(bunga.persen))}</div></td><td class="px-6 py-4"><div class="text-sm text-gray-600 max-w-xs truncate">${escape_html(bunga.deskripsi || "-")}</div></td><td class="px-6 py-4 whitespace-nowrap"><span${attr_class(`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${stringify(bunga.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800")}`)}>${escape_html(bunga.is_active ? "Aktif" : "Nonaktif")}</span></td><td class="px-6 py-4 whitespace-nowrap"><div class="text-sm text-gray-600">${escape_html(bunga.created_by_user?.name || `ID: ${bunga.created_by}`)}</div></td><td class="px-6 py-4 whitespace-nowrap"><div class="text-sm text-gray-600">${escape_html(new Date(bunga.created_at).toLocaleDateString("id-ID"))}</div></td>`);
        if (canManageBunga) {
          $$payload.out.push("<!--[-->");
          $$payload.out.push(`<td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium"><div class="flex justify-end space-x-2"><button class="text-blue-600 hover:text-blue-900 transition-colors" title="Edit"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg></button> <button${attr_class(`${stringify(bunga.is_active ? "text-red-600 hover:text-red-900" : "text-green-600 hover:text-green-900")} transition-colors`)}${attr("title", bunga.is_active ? "Nonaktifkan" : "Aktifkan")}>`);
          if (bunga.is_active) {
            $$payload.out.push("<!--[-->");
            $$payload.out.push(`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728L5.636 5.636m12.728 12.728L5.636 5.636"></path></svg>`);
          } else {
            $$payload.out.push("<!--[!-->");
            $$payload.out.push(`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>`);
          }
          $$payload.out.push(`<!--]--></button> <button class="text-red-600 hover:text-red-900 transition-colors" title="Hapus"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button></div></td>`);
        } else {
          $$payload.out.push("<!--[!-->");
        }
        $$payload.out.push(`<!--]--></tr>`);
      }
      $$payload.out.push(`<!--]--></tbody></table></div></div>`);
    }
    $$payload.out.push(`<!--]-->`);
  }
  $$payload.out.push(`<!--]--></div> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]-->`);
  bind_props($$props, { data });
  pop();
}
export {
  _page as default
};

import { redirect } from "@sveltejs/kit";
const load = async ({ cookies }) => {
  const token = cookies.get("token");
  if (!token) {
    console.log("🚫 No token found, redirecting to login");
    throw redirect(302, "/login");
  }
  try {
    const response = await fetch("http://localhost:8080/api/me", {
      headers: {
        "Authorization": token,
        "Content-Type": "application/json"
      }
    });
    if (!response.ok) {
      throw new Error("Authentication failed");
    }
    const userData = await response.json();
    let currentUser = userData.data || userData;
    if (currentUser.role_id && !currentUser.role) {
      currentUser.role = {
        id: currentUser.role_id,
        name: currentUser.role_id === 1 ? "super_admin" : currentUser.role_id === 2 ? "admin" : "member"
      };
    }
    const canManageBunga = currentUser.role?.name === "admin" || currentUser.role?.name === "super_admin";
    console.log("🔍 Bunga page access:", {
      user: currentUser.email,
      role: currentUser.role?.name,
      canManageBunga
    });
    if (!canManageBunga) {
      console.log("🚫 User does not have permission to manage bunga");
      throw redirect(302, "/dashboard");
    }
    return {
      bungaOptions: [],
      // Will be loaded client-side
      currentUser,
      canManageBunga
    };
  } catch (error) {
    console.log("🚫 Authentication error:", error);
    throw redirect(302, "/login");
  }
};
export {
  load
};

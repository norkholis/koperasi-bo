import { D as escape_html, A as ensure_array_like, B as attr_class, E as stringify, I as attr, N as bind_props, y as pop, w as push } from "../../../../chunks/index2.js";
import "@sveltejs/kit/internal";
import "../../../../chunks/exports.js";
import "../../../../chunks/utils.js";
import "../../../../chunks/state.svelte.js";
import "../../../../chunks/api.js";
function _page($$payload, $$props) {
  push();
  let data = $$props["data"];
  let wallets = data.wallets || [];
  let pendingTransactions = data.pendingTransactions || [];
  const currentUser = data.currentUser;
  const selectedUserId = data.selectedUserId;
  console.log("🚀 Simpanan page loaded");
  console.log("👤 Current user:", currentUser?.email, currentUser?.role?.name);
  console.log("🎯 Selected User ID:", selectedUserId);
  console.log("💼 Wallets count:", wallets.length);
  if (wallets.length > 0) {
    console.log("✅ Wallets loaded successfully:", wallets.length);
    console.log("🔍 First wallet:", wallets[0]);
  } else {
    console.log("⚠️ No wallets found");
  }
  if (data.error) {
    console.error("❌ Page data error:", data.error);
  }
  const isAdmin = currentUser?.role?.name === "admin" || currentUser?.role?.name === "super_admin";
  const isMember = currentUser?.role?.name === "member";
  let isNavigating = false;
  function formatCurrency(amount) {
    if (amount === null || amount === void 0 || isNaN(amount)) {
      return "Rp 0";
    }
    return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(amount);
  }
  function formatDate(dateString) {
    if (!dateString) {
      return "Tanggal tidak tersedia";
    }
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        return "Tanggal tidak valid";
      }
      return date.toLocaleDateString("id-ID", {
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      });
    } catch (error) {
      console.error("Error formatting date:", error);
      return "Tanggal error";
    }
  }
  function getWalletByType(type) {
    return wallets.find((w) => w.type === type);
  }
  function getWalletDisplayName(type) {
    const names = {
      pokok: "Simpanan Pokok",
      wajib: "Simpanan Wajib",
      sukarela: "Simpanan Sukarela"
    };
    return names[type] || type;
  }
  function getWalletColor(type) {
    const colors = {
      pokok: "bg-purple-100 text-purple-800 border-purple-200",
      wajib: "bg-blue-100 text-blue-800 border-blue-200",
      sukarela: "bg-green-100 text-green-800 border-green-200"
    };
    return colors[type] || "bg-gray-100 text-gray-800 border-gray-200";
  }
  $$payload.out.push(`<div class="p-6"><div class="flex items-center justify-between mb-6"><div class="flex items-center gap-4"><h1 class="text-2xl font-bold">${escape_html(isMember ? "Wallet Wadiah Saya" : "Manajemen Wallet Wadiah")}</h1> `);
  if (selectedUserId && isAdmin) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<a href="/dashboard/simpanan" class="text-sm text-blue-600 hover:text-blue-800 underline">← Kembali ke Semua Wallet</a>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--></div> `);
  if (selectedUserId && isAdmin) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<div class="text-sm text-gray-600">Menampilkan wallet untuk User ID: #${escape_html(selectedUserId)}</div>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--></div> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (isMember || selectedUserId) {
    $$payload.out.push("<!--[-->");
    const each_array = ensure_array_like(["pokok", "wajib", "sukarela"]);
    $$payload.out.push(`<div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"><!--[-->`);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let walletType = each_array[$$index];
      const wallet = getWalletByType(walletType);
      $$payload.out.push(`<div${attr_class(`bg-white rounded-lg shadow-md border-2 ${stringify(getWalletColor(walletType))} p-6`)}><div class="flex items-center justify-between mb-4"><h3 class="text-lg font-semibold">${escape_html(getWalletDisplayName(walletType))}</h3> <div${attr_class(`text-sm px-2 py-1 rounded-full ${stringify(getWalletColor(walletType))}`)}>${escape_html(walletType.toUpperCase())}</div></div> <div class="mb-4"><p class="text-sm text-gray-600 mb-1">Saldo Saat Ini</p> <p class="text-2xl font-bold text-gray-900">${escape_html(wallet ? formatCurrency(wallet.balance) : formatCurrency(0))}</p></div> `);
      if (wallet) {
        $$payload.out.push("<!--[-->");
        $$payload.out.push(`<div class="text-xs text-gray-500 mb-4">Diperbarui: ${escape_html(formatDate(wallet.updated_at))}</div> <div class="flex gap-2 flex-wrap">`);
        if (isMember) {
          $$payload.out.push("<!--[-->");
          $$payload.out.push(`<button class="flex-1 px-3 py-2 text-sm bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors">Top Up</button>`);
        } else {
          $$payload.out.push("<!--[!-->");
          if (isAdmin) {
            $$payload.out.push("<!--[-->");
            $$payload.out.push(`<button class="flex-1 px-3 py-2 text-sm bg-green-500 text-white rounded hover:bg-green-600 transition-colors">Sesuaikan Saldo</button>`);
          } else {
            $$payload.out.push("<!--[!-->");
          }
          $$payload.out.push(`<!--]-->`);
        }
        $$payload.out.push(`<!--]--> `);
        if (wallet) {
          $$payload.out.push("<!--[-->");
          $$payload.out.push(`<button class="flex-1 px-3 py-2 text-sm bg-gray-500 text-white rounded hover:bg-gray-600 transition-colors">Riwayat</button>`);
        } else {
          $$payload.out.push("<!--[!-->");
        }
        $$payload.out.push(`<!--]--></div>`);
      } else {
        $$payload.out.push("<!--[!-->");
        $$payload.out.push(`<div class="text-center py-4"><p class="text-gray-500 text-sm mb-3">Wallet belum tersedia</p> <p class="text-xs text-gray-400">Wallet akan dibuat otomatis saat registrasi</p></div>`);
      }
      $$payload.out.push(`<!--]--></div>`);
    }
    $$payload.out.push(`<!--]--></div>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (isAdmin && pendingTransactions.length > 0) {
    $$payload.out.push("<!--[-->");
    const each_array_1 = ensure_array_like(pendingTransactions);
    $$payload.out.push(`<div class="bg-white rounded-lg shadow-md mb-6"><div class="px-6 py-4 border-b border-gray-200"><h2 class="text-lg font-semibold text-gray-900">Permintaan Top-Up Menunggu Persetujuan <span class="ml-2 px-2 py-1 text-xs bg-orange-100 text-orange-800 rounded-full">${escape_html(pendingTransactions.length)}</span></h2></div> <div class="overflow-x-auto"><table class="w-full"><thead class="bg-gray-50"><tr><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Wallet</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jumlah</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Keterangan</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th></tr></thead><tbody class="bg-white divide-y divide-gray-200"><!--[-->`);
    for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
      let transaction = each_array_1[$$index_1];
      $$payload.out.push(`<tr class="hover:bg-gray-50"><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(formatDate(transaction.created_at))}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">#${escape_html(transaction.simpanan?.user_id || "Unknown")}</td><td class="px-6 py-4 whitespace-nowrap"><span${attr_class(`px-2 py-1 text-xs rounded-full ${stringify(getWalletColor(transaction.simpanan?.type || ""))}`)}>${escape_html(getWalletDisplayName(transaction.simpanan?.type || ""))}</span></td><td class="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">${escape_html(formatCurrency(transaction.amount))}</td><td class="px-6 py-4 text-sm text-gray-600">${escape_html(transaction.description)}</td><td class="px-6 py-4 whitespace-nowrap text-sm font-medium"><div class="flex gap-2"><button class="px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600 transition-colors">Setujui</button> <button class="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 transition-colors">Tolak</button> <button class="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors">Detail</button></div></td></tr>`);
    }
    $$payload.out.push(`<!--]--></tbody></table></div></div>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (isAdmin && !selectedUserId && wallets.length > 0) {
    $$payload.out.push("<!--[-->");
    const each_array_2 = ensure_array_like(wallets);
    $$payload.out.push(`<div class="bg-white rounded-lg shadow-md"><div class="px-6 py-4 border-b border-gray-200"><h2 class="text-lg font-semibold text-gray-900">Semua Wallet Pengguna</h2></div> <div class="overflow-x-auto"><table class="w-full"><thead class="bg-gray-50"><tr><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User ID</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama User</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jenis Wallet</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Saldo</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Terakhir Update</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th></tr></thead><tbody class="bg-white divide-y divide-gray-200"><!--[-->`);
    for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
      let wallet = each_array_2[$$index_2];
      $$payload.out.push(`<tr class="hover:bg-gray-50"><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">#${escape_html(wallet.user_id)}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escape_html(wallet.user?.name || "-")}</td><td class="px-6 py-4 whitespace-nowrap"><span${attr_class(`px-2 py-1 text-xs rounded-full ${stringify(getWalletColor(wallet.type))}`)}>${escape_html(getWalletDisplayName(wallet.type))}</span></td><td class="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">${escape_html(formatCurrency(wallet.balance))}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">${escape_html(formatDate(wallet.updated_at))}</td><td class="px-6 py-4 whitespace-nowrap text-sm font-medium"><div class="flex gap-2"><button class="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors">Sesuaikan</button> <button class="px-3 py-1 bg-gray-500 text-white rounded hover:bg-gray-600 transition-colors">Riwayat</button> <button${attr("disabled", isNavigating, true)} class="px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">`);
      {
        $$payload.out.push("<!--[!-->");
        $$payload.out.push(`Lihat Detail`);
      }
      $$payload.out.push(`<!--]--></button></div></td></tr>`);
    }
    $$payload.out.push(`<!--]--></tbody></table></div></div>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (wallets.length === 0) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<div class="bg-white rounded-lg shadow-md p-8 text-center"><div class="text-gray-400 mb-4"><svg class="w-16 h-16 mx-auto" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M4 4a2 2 0 00-2 2v8a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2H4zm0 2h12v8H4V6z" clip-rule="evenodd"></path><path d="M9 8a1 1 0 011-1h2a1 1 0 110 2h-2A1 1 0 019 8z"></path></svg></div> <h3 class="text-lg font-medium text-gray-900 mb-2">Belum Ada Wallet</h3> <p class="text-gray-600">${escape_html(isMember ? "Wallet Anda akan dibuat otomatis. Silahkan hubungi admin jika ada pertanyaan." : "Belum ada data wallet untuk ditampilkan.")}</p></div>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--></div> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]-->`);
  bind_props($$props, { data });
  pop();
}
export {
  _page as default
};

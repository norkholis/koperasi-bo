import "clsx";
import { y as pop, w as push } from "../../chunks/index2.js";
import "@sveltejs/kit/internal";
import "../../chunks/exports.js";
import "../../chunks/utils.js";
import "../../chunks/state.svelte.js";
function _page($$payload, $$props) {
  push();
  $$payload.out.push(`<div class="min-h-screen flex items-center justify-center bg-gray-100"><div class="text-center"><div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div> <p class="text-gray-600">Redirecting...</p></div></div>`);
  pop();
}
export {
  _page as default
};

const load = async ({ locals, url }) => {
  const user = locals.user || null;
  return {
    user,
    pathname: url.pathname
  };
};
export {
  load
};

import { a as axios, e as extractErrorMessage } from "../../../chunks/api.js";
const actions = {
  default: async ({ request, cookies }) => {
    const data = await request.formData();
    const email = data.get("email");
    const password = data.get("password");
    try {
      const res = await axios.post("/login", { email, password });
      console.log("Login response:", JSON.stringify(res.data, null, 2));
      if (res.data?.data) {
        const dataField = res.data.data;
        if (typeof dataField === "string") {
          try {
            const parsedData = JSON.parse(dataField);
            if (Array.isArray(parsedData) && parsedData.length >= 2) {
              if (parsedData[0]?.error === 1) {
                let errorMsg = parsedData[1] || "Login failed";
                if (errorMsg.includes("EPROTO") || errorMsg.includes("SSL")) {
                  errorMsg = "Authentication service temporarily unavailable. Please try again.";
                }
                return { error: errorMsg };
              }
            }
          } catch (parseError) {
            console.error("Failed to parse data field:", parseError);
          }
        }
      }
      const token = res.data?.token || res.data?.data?.token;
      if (!token) {
        console.error("No token in response:", res.data);
        return { error: "Login failed: Invalid response from server" };
      }
      cookies.set("token", token, {
        path: "/",
        httpOnly: false,
        sameSite: "lax",
        maxAge: 60 * 60 * 24
      });
      return { token };
    } catch (e) {
      console.error("Login error:", e);
      const errorMessage = extractErrorMessage(e);
      return { error: errorMessage };
    }
  }
};
export {
  actions
};

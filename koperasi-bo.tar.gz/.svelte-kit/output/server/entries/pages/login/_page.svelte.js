import { G as head, D as escape_html, N as bind_props, y as pop, w as push } from "../../../chunks/index2.js";
import "@sveltejs/kit/internal";
import "../../../chunks/exports.js";
import "../../../chunks/utils.js";
import "clsx";
import "../../../chunks/state.svelte.js";
function _page($$payload, $$props) {
  push();
  let form = $$props["form"];
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>Login Backoffice</title>`;
  });
  $$payload.out.push(`<div class="min-h-screen flex items-center justify-center bg-gray-100"><form method="POST" class="bg-white p-6 rounded shadow-md w-96"><h1 class="text-xl font-semibold mb-4">Backoffice Login</h1> `);
  if (form?.error) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<p class="text-red-600 mb-2">${escape_html(form.error)}</p>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> <label class="block mb-2">Email <input name="email" type="email" required class="w-full border px-3 py-2 rounded"/></label> <label class="block mb-4">Password <input name="password" type="password" required class="w-full border px-3 py-2 rounded"/></label> <button class="w-full bg-blue-600 text-white py-2 rounded">Masuk</button></form></div>`);
  bind_props($$props, { form });
  pop();
}
export {
  _page as default
};

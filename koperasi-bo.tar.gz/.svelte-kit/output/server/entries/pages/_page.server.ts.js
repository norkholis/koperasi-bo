import { redirect } from "@sveltejs/kit";
import { a as axios } from "../../chunks/api.js";
const load = async ({ cookies }) => {
  const token = cookies.get("token");
  if (token) {
    try {
      axios.defaults.headers.Authorization = `Bearer ${token}`;
      await axios.get("/me");
      throw redirect(303, "/dashboard");
    } catch (error) {
      cookies.delete("token", { path: "/" });
    }
  }
  return {};
};
export {
  load
};

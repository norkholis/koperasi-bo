import { json } from "@sveltejs/kit";
async function GET() {
  console.log("🧪 SvelteKit API route /api/test was called");
  return json({
    message: "SvelteKit API route is working!",
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    server: "SvelteKit"
  });
}
export {
  GET
};

function formatCurrency(amount) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0
  }).format(amount);
}
function formatDate(dateString) {
  if (!dateString) {
    return "Tanggal tidak tersedia";
  }
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) {
      console.warn("Invalid date string:", dateString);
      return "Tanggal tidak valid";
    }
    return date.toLocaleDateString("id-ID", {
      year: "numeric",
      month: "long",
      day: "numeric"
    });
  } catch (error) {
    console.error("Error formatting date:", dateString, error);
    return "Format tanggal error";
  }
}
export {
  formatDate as a,
  formatCurrency as f
};

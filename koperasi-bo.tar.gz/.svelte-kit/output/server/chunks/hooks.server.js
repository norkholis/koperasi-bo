import { redirect } from "@sveltejs/kit";
import { a as axios } from "./api.js";
const handle = async ({ event, resolve }) => {
  const token = event.cookies.get("token");
  const url = event.url;
  const publicRoutes = ["/login", "/register"];
  const isPublicRoute = publicRoutes.some((route) => url.pathname.startsWith(route));
  if (!token && !isPublicRoute && url.pathname !== "/") {
    throw redirect(303, "/login");
  }
  if (token && (url.pathname === "/login" || url.pathname === "/register")) {
    throw redirect(303, "/dashboard");
  }
  if (url.pathname === "/") {
    if (token) {
      try {
        axios.defaults.headers.Authorization = `Bearer ${token}`;
        await axios.get("/me");
        throw redirect(303, "/dashboard");
      } catch (error) {
        event.cookies.delete("token", { path: "/" });
        throw redirect(303, "/login");
      }
    } else {
      throw redirect(303, "/login");
    }
  }
  if (token && !isPublicRoute) {
    try {
      axios.defaults.headers.Authorization = `Bearer ${token}`;
      const response = await axios.get("/me");
      let userData = response.data;
      if (userData.data) {
        userData = userData.data;
      }
      if (userData.role_id && !userData.role) {
        userData.role = {
          id: userData.role_id,
          name: userData.role_id === 1 ? "super_admin" : userData.role_id === 2 ? "admin" : "member"
        };
      }
      event.locals.user = userData;
    } catch (error) {
      event.cookies.delete("token", { path: "/" });
      throw redirect(303, "/login");
    }
  }
  return resolve(event);
};
export {
  handle
};

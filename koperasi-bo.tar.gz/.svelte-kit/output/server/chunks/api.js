import axios$1 from "axios";
import { D as DEV } from "./false.js";
import "clsx";
import "@sveltejs/kit/internal";
import "./exports.js";
import "./utils.js";
import "./state.svelte.js";
const browser = DEV;
function extractErrorMessage(error) {
  let errorMessage = "An error occurred";
  if (error?.response?.data) {
    const responseData = error.response.data;
    if (responseData.data) {
      try {
        if (typeof responseData.data === "string") {
          const parsedData = JSON.parse(responseData.data);
          if (Array.isArray(parsedData) && parsedData.length > 1) {
            errorMessage = parsedData[1];
          } else {
            errorMessage = responseData.data;
          }
        } else if (typeof responseData.data === "object") {
          errorMessage = responseData.data.message || responseData.data.error || errorMessage;
        } else {
          errorMessage = responseData.data;
        }
      } catch (e) {
        errorMessage = responseData.data;
      }
    } else if (responseData.message) {
      errorMessage = responseData.message;
    } else if (responseData.error) {
      errorMessage = responseData.error;
    } else if (responseData.type === "failure") {
      errorMessage = "Request failed";
    }
  } else if (error?.message) {
    errorMessage = error.message;
  }
  return errorMessage;
}
function isErrorResponse(response) {
  const isSuccessStatus = response.status >= 200 && response.status < 300;
  const hasFailureType = response.data && response.data.type === "failure";
  return !isSuccessStatus || hasFailureType;
}
const PUBLIC_API_URL = "https://koperasi-api.nirantara.cloud/api";
console.log("🔧 API Configuration - PUBLIC_API_URL:", PUBLIC_API_URL);
const axios = axios$1.create({
  baseURL: PUBLIC_API_URL,
  headers: { "Content-Type": "application/json" }
});
console.log("🔧 Axios instance created with baseURL:", axios.defaults.baseURL);
axios.interceptors.request.use((config) => {
  const timestamp = (/* @__PURE__ */ new Date()).toISOString();
  console.log(`🌐 [${"SERVER"}] ${timestamp}`);
  console.log(`📤 ${config.method?.toUpperCase()} ${config.baseURL}${config.url}`);
  if (config.data) {
    console.log("📦 Request Body:", config.data);
  }
  if (config.params) {
    console.log("🔍 Query Params:", config.params);
  }
  console.log("🔑 Headers:", {
    "Content-Type": config.headers["Content-Type"],
    "Authorization": config.headers.Authorization ? "Bearer [HIDDEN]" : "None"
  });
  console.log("─".repeat(50));
  return config;
});
axios.interceptors.response.use(
  (res) => {
    const timestamp = (/* @__PURE__ */ new Date()).toISOString();
    console.log(`🌐 [${"SERVER"}] ${timestamp}`);
    console.log(`📥 Response ${res.status} ${res.config.method?.toUpperCase()} ${res.config.url}`);
    console.log("📊 Response Data:", res.data);
    console.log("─".repeat(50));
    if (isErrorResponse(res)) {
      const timestamp2 = (/* @__PURE__ */ new Date()).toISOString();
      console.error(`🌐 [${"SERVER"}] ${timestamp2}`);
      console.error(`❌ API Error ${res.status} ${res.config.method?.toUpperCase()} ${res.config.url}`);
      console.error("💥 Error Response:", res.data);
      console.error("─".repeat(50));
      const errorMessage = extractErrorMessage({ response: res });
      const error = new Error(errorMessage);
      error.response = res;
      error.status = res.status;
      error.data = res.data;
      return Promise.reject(error);
    }
    return res;
  },
  (err) => {
    const timestamp = (/* @__PURE__ */ new Date()).toISOString();
    console.error(`🌐 [${"SERVER"}] ${timestamp}`);
    console.error(`❌ Error ${err.response?.status || "NETWORK"} ${err.config?.method?.toUpperCase()} ${err.config?.url}`);
    console.error("💥 Error Data:", err.response?.data || err.message);
    console.error("─".repeat(50));
    if (err.response?.status === 401 && browser) ;
    return Promise.reject(err);
  }
);
export {
  axios as a,
  extractErrorMessage as e
};

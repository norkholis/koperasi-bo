

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/dashboard/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/4.aHZgqlrK.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/B5KjFJxM.js","_app/immutable/chunks/C9qTkyRV.js","_app/immutable/chunks/BwfT9sh7.js","_app/immutable/chunks/DrL32GsD.js","_app/immutable/chunks/w11sZsPk.js","_app/immutable/chunks/DU1eSaYB.js","_app/immutable/chunks/Bn3wqLzT.js"];
export const stylesheets = [];
export const fonts = [];

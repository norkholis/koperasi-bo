import * as server from '../entries/pages/dashboard/reporting/_page.server.ts.js';

export const index = 10;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/dashboard/reporting/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/dashboard/reporting/+page.server.ts";
export const imports = ["_app/immutable/nodes/10.bNBdaXPg.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/B5KjFJxM.js","_app/immutable/chunks/C9qTkyRV.js","_app/immutable/chunks/DUrHb5po.js","_app/immutable/chunks/w11sZsPk.js","_app/immutable/chunks/DU1eSaYB.js","_app/immutable/chunks/DJs5tiY5.js"];
export const stylesheets = [];
export const fonts = [];

import * as universal from '../entries/pages/dashboard/member/_page.ts.js';

export const index = 6;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/dashboard/member/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/dashboard/member/+page.ts";
export const imports = ["_app/immutable/nodes/6.BMrdQcNj.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/B5KjFJxM.js","_app/immutable/chunks/C9qTkyRV.js","_app/immutable/chunks/DUrHb5po.js","_app/immutable/chunks/w11sZsPk.js","_app/immutable/chunks/DU1eSaYB.js"];
export const stylesheets = [];
export const fonts = [];

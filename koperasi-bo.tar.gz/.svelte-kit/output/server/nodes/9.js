import * as universal from '../entries/pages/dashboard/profile/_page.ts.js';
import * as server from '../entries/pages/dashboard/profile/_page.server.ts.js';

export const index = 9;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/dashboard/profile/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/dashboard/profile/+page.ts";
export { server };
export const server_id = "src/routes/dashboard/profile/+page.server.ts";
export const imports = ["_app/immutable/nodes/9.DQVosJ2A.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/B5KjFJxM.js","_app/immutable/chunks/C9qTkyRV.js","_app/immutable/chunks/DUrHb5po.js","_app/immutable/chunks/6IzYFha_.js","_app/immutable/chunks/Bn3wqLzT.js","_app/immutable/chunks/BwfT9sh7.js","_app/immutable/chunks/DrL32GsD.js","_app/immutable/chunks/BS9nNCo2.js","_app/immutable/chunks/w11sZsPk.js","_app/immutable/chunks/DU1eSaYB.js"];
export const stylesheets = [];
export const fonts = [];

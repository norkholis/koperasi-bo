import * as universal from '../entries/pages/dashboard/super/_page.ts.js';

export const index = 15;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/dashboard/super/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/dashboard/super/+page.ts";
export const imports = ["_app/immutable/nodes/15.BrAv-aUH.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/B5KjFJxM.js","_app/immutable/chunks/C9qTkyRV.js","_app/immutable/chunks/DUrHb5po.js","_app/immutable/chunks/w11sZsPk.js","_app/immutable/chunks/DU1eSaYB.js"];
export const stylesheets = [];
export const fonts = [];

import * as server from '../entries/pages/dashboard/_layout.server.ts.js';

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/dashboard/_layout.svelte.js')).default;
export { server };
export const server_id = "src/routes/dashboard/+layout.server.ts";
export const imports = ["_app/immutable/nodes/2.Mj5AlZno.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/B5KjFJxM.js","_app/immutable/chunks/C9qTkyRV.js","_app/immutable/chunks/DUrHb5po.js","_app/immutable/chunks/BS9nNCo2.js","_app/immutable/chunks/CDzzSuJj.js","_app/immutable/chunks/w11sZsPk.js","_app/immutable/chunks/DU1eSaYB.js","_app/immutable/chunks/Bn3wqLzT.js","_app/immutable/chunks/BwfT9sh7.js","_app/immutable/chunks/DrL32GsD.js"];
export const stylesheets = [];
export const fonts = [];

import * as universal from '../entries/pages/dashboard/admin/_page.ts.js';

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/dashboard/admin/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/dashboard/admin/+page.ts";
export const imports = ["_app/immutable/nodes/5.DbKH_HAP.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/B5KjFJxM.js","_app/immutable/chunks/C9qTkyRV.js","_app/immutable/chunks/DUrHb5po.js","_app/immutable/chunks/w11sZsPk.js","_app/immutable/chunks/DU1eSaYB.js"];
export const stylesheets = [];
export const fonts = [];

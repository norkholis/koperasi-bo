import * as server from '../entries/pages/_layout.server.ts.js';

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export { server };
export const server_id = "src/routes/+layout.server.ts";
export const imports = ["_app/immutable/nodes/0.BWdG163U.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/C9qTkyRV.js","_app/immutable/chunks/DrL32GsD.js","_app/immutable/chunks/BS9nNCo2.js","_app/immutable/chunks/B5KjFJxM.js","_app/immutable/chunks/DUrHb5po.js","_app/immutable/chunks/tmalTpZp.js","_app/immutable/chunks/CDzzSuJj.js","_app/immutable/chunks/DU1eSaYB.js","_app/immutable/chunks/XFodv2qd.js"];
export const stylesheets = ["_app/immutable/assets/0.C-JQGNoM.css"];
export const fonts = [];

import{H as t}from"./Bn3wqLzT.js";function n(r,o){throw new t(r,o)}export{n as e};

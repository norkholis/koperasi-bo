import{l as o,d as r}from"../chunks/Bn3wqLzT.js";export{o as load_css,r as start};

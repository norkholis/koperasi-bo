import * as universal from '../entries/pages/dashboard/users/_id_/_page.ts.js';
import * as server from '../entries/pages/dashboard/users/_id_/_page.server.ts.js';

export const index = 17;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/dashboard/users/_id_/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/dashboard/users/[id]/+page.ts";
export { server };
export const server_id = "src/routes/dashboard/users/[id]/+page.server.ts";
export const imports = ["_app/immutable/nodes/17.A7rHaBfH.js","_app/immutable/chunks/Ds2Eahi1.js","_app/immutable/chunks/BEGuUAQ3.js","_app/immutable/chunks/BwfT9sh7.js","_app/immutable/chunks/C9qTkyRV.js","_app/immutable/chunks/DrL32GsD.js","_app/immutable/chunks/XFodv2qd.js","_app/immutable/chunks/BZhHO05J.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/B5KjFJxM.js","_app/immutable/chunks/DUrHb5po.js","_app/immutable/chunks/DfAAHOrb.js","_app/immutable/chunks/BS9nNCo2.js","_app/immutable/chunks/w11sZsPk.js","_app/immutable/chunks/DU1eSaYB.js"];
export const stylesheets = [];
export const fonts = [];

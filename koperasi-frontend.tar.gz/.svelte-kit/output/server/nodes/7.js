import * as server from '../entries/pages/dashboard/pinjaman/_page.server.ts.js';

export const index = 7;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/dashboard/pinjaman/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/dashboard/pinjaman/+page.server.ts";
export const imports = ["_app/immutable/nodes/7.DpHhf_HV.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/B5KjFJxM.js","_app/immutable/chunks/C9qTkyRV.js","_app/immutable/chunks/BwfT9sh7.js","_app/immutable/chunks/DrL32GsD.js","_app/immutable/chunks/DUrHb5po.js","_app/immutable/chunks/tmalTpZp.js","_app/immutable/chunks/BS9nNCo2.js","_app/immutable/chunks/CDzzSuJj.js","_app/immutable/chunks/pRpwmIHK.js","_app/immutable/chunks/BM0ZIpWA.js","_app/immutable/chunks/CdEA5IGF.js","_app/immutable/chunks/CjF8rRIF.js","_app/immutable/chunks/BEGuUAQ3.js","_app/immutable/chunks/w11sZsPk.js","_app/immutable/chunks/DU1eSaYB.js","_app/immutable/chunks/Ds2Eahi1.js","_app/immutable/chunks/XFodv2qd.js"];
export const stylesheets = [];
export const fonts = [];

import{H as t}from"./BEGuUAQ3.js";function n(r,o){throw new t(r,o)}export{n as e};
